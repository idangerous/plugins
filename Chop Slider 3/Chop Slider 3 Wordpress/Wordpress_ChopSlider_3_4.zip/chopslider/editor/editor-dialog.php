<?php

// Path to WordPress Root
$absolute_path = __FILE__;
$path_to_file = explode( 'wp-content', $absolute_path );
$path_to_wp = $path_to_file[0];

// Access to WordPress
require_once( $path_to_wp . '/wp-load.php' );
$id = $_GET['id'];
global $wpdb;
$chopslider_result = $wpdb->get_results('SELECT chopslider_id, title FROM ' . CHOPSLIDER_TABLE_NAME . ' ORDER BY chopslider_id DESC'); 
$wpdb->flush();
?>
<script>
function insertCS(id) {
	window.parent.tinymce.execCommand('mceInsertContent', false, '[chopslider id="'+id+'"]');
	window.parent.tinymce.activeEditor.windowManager.close(window)
}
</script>
<p style="font-size:13px;">Choose the Chop Slider you want to insert:</p>
<ul>
<?php foreach ($chopslider_result as $cs)  {
		echo '
		<li  style="font-size:13px;"><a style="color:#21759B" href="#" onclick="insertCS(' . $cs -> chopslider_id . '); return false;">' . $cs -> title . '</a></li>	
		';
	}
?>
</ul>