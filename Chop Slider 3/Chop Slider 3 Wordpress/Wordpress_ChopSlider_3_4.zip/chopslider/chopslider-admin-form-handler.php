<?php

function cs3ReplaceQuotes($a) {
	return str_replace(array("\'", '\"'), array("'", '"'), $a);
};

$newCS = array();
$newCS['slides'] = array();

foreach ( $_POST['image'] as $key => $value ) {
	$newCS['slides'][$key] = array();
	$newCS['slides'][$key]['image'] = $value;
	$newCS['slides'][$key]['title'] = trim(cs3ReplaceQuotes($_POST['title'][$key]));
	$newCS['slides'][$key]['text'] = trim(cs3ReplaceQuotes($_POST['text'][$key]));
	$newCS['slides'][$key]['link'] = $_POST['link'][$key];
	$newCS['slides'][$key]['videoID'] = $_POST['videoID'][$key];
	$newCS['slides'][$key]['videoService'] = $_POST['videoService'][$key];
};

/* Main Parameters */
$title = $_POST['slider-title'];
$newCS['autoSize'] = $_POST['autoSize'];
$newCS['width'] = $_POST['width'];
$newCS['height'] = $_POST['height'];
$newCS['responsive'] = $_POST['responsive'];
$newCS['preloader'] = $_POST['preloader'];
$newCS['preloadOnlyFirst'] = $_POST['preloadOnlyFirst'];
$newCS['skin'] = $_POST['skin'];

$newCS['autoplay'] = $_POST['autoplay'];
$newCS['autoplayDelay'] = $_POST['autoplayDelay'];
$newCS['disableOnInteraction'] = $_POST['disableOnInteraction'];

$newCS['navigation'] = $_POST['navigation'];
$newCS['pagination'] = $_POST['pagination'];
$newCS['hideOnStart'] = $_POST['hideOnStart'];
$newCS['showOnlyOnHover'] = $_POST['showOnlyOnHover'];

$newCS['captions'] = $_POST['captions'];
$newCS['captionsDuration'] = $_POST['captionsDuration'];
$newCS['captionsType'] = $_POST['captionsType'];
$newCS['captionsMulti'] = $_POST['captionsMulti'];
$newCS['multiDelay'] = $_POST['multiDelay'];
$newCS['captionType'] = $_POST['captionType'];
$newCS['captionColor'] = $_POST['captionColor'];
$newCS['captionPosition'] = $_POST['captionPosition'];

$newCS['gallery'] = $_POST['gallery'];
$newCS['showCaptions'] = $_POST['showCaptions'];
$newCS['galleryColor'] = $_POST['galleryColor'];
$newCS['galleryPosition'] = $_POST['galleryPosition'];

$newCS['ambilight'] = $_POST['ambilight'];
$newCS['ambilightSize'] = $_POST['ambilightSize'];
$newCS['colorIndex'] = $_POST['colorIndex'];
$newCS['fadeIndex'] = $_POST['fadeIndex'];

$newCS['touch'] = $_POST['touch'];
$newCS['touchEffect'] = $_POST['touchEffect'];

$newCS['onInit'] = trim(cs3ReplaceQuotes($_POST['onInit']));
$newCS['onTransitionStart'] = trim(cs3ReplaceQuotes($_POST['onTransitionStart']));
$newCS['onTransitionEnd'] = trim(cs3ReplaceQuotes($_POST['onTransitionEnd']));

//Effects
$effects = array();

if (isset($_POST['e-flat']) && count($_POST['e-flat'])>0 ) {
	if ( in_array('random-flat', $_POST['e-flat']) ) array_push($effects,'random-flat');	
	else {
		foreach( $_POST['e-flat'] as $value ) array_push($effects,$value); 	
	}
}

if (isset($_POST['e-2d']) && count($_POST['e-2d'])>0 ) {
	if ( in_array('random-2d', $_POST['e-2d']) ) array_push($effects,'random-2d');	
	else {
		foreach( $_POST['e-2d'] as $value ) array_push($effects,$value); 	
	}
}

if (isset($_POST['e-3d']) && count($_POST['e-3d'])>0 ) {
	if ( in_array('random-3d', $_POST['e-3d']) ) array_push($effects,'random-3d');	
	else {
		foreach( $_POST['e-3d'] as $value ) array_push($effects,$value); 	
	}
}

if (isset($_POST['e-canvas']) && count($_POST['e-canvas'])>0 ) {
	if ( in_array('random-canvas', $_POST['e-canvas']) ) array_push($effects,'random-canvas');	
	else {
		foreach( $_POST['e-canvas'] as $value ) array_push($effects,$value); 	
	}
}

$newCS['effects'] = implode(',',$effects);
if (!empty($_POST['effectsGroupLock-support3d']))
	$newCS['effectsGroupLock-support3d'] = implode(',',$_POST['effectsGroupLock-support3d']);
if (!empty($_POST['effectsGroupLock-support2d']))
	$newCS['effectsGroupLock-support2d'] = implode(',', $_POST['effectsGroupLock-support2d']);
if (!empty($_POST['effectsGroupLock-supportCanvasNoCSS3']))
	$newCS['effectsGroupLock-supportCanvasNoCSS3'] = implode(',', $_POST['effectsGroupLock-supportCanvasNoCSS3']);

if( isset( $_POST['create-chopslider'] ) ) {
	/*
	Now we need to add all information into DB table
	*/
	
	global $wpdb;
	$new_chopslider_row = $wpdb->insert( 
		CHOPSLIDER_TABLE_NAME, 
		array( 'title' => $title, 'options' => serialize($newCS), 'version' => '1', 'created' => current_time('mysql') ) 
	);
	
	
	if( $new_chopslider_row ) {
		$chopslider_status = 'Congratulations! New Chop Slider was successfully added!';
		$chopslider_status_class = 'updated';
		$new_chopslider_ID = $wpdb->get_var(
			"
			SELECT MAX(chopslider_id) from " . CHOPSLIDER_TABLE_NAME . "
			"
		);
	}
	else {
		$chopslider_status = 'Error occured while adding new Chop Slider!';
		$chopslider_status_class = 'error';
	};
	
	$wpdb->flush();
	
	
};

if( isset( $_POST['save-edited-chopslider'] ) ) {
	/*
	Now we need to update all information into DB table
	*/
	global $wpdb;
	$update_chopslider_row = $wpdb->update( 
		CHOPSLIDER_TABLE_NAME, 
		array( 'title' => $title, 'options' => serialize($newCS), 'version' => $_POST['version'], 'created' => current_time('mysql') ), 
		array( 'chopslider_id' => $_POST['id'] ) 
	);
	$wpdb->flush();
	
	if( $update_chopslider_row ) {
		$chopslider_status = 'Slider '.$title.' was successfully updated!';
		$chopslider_status_class = 'updated';
	}
	else {
		$chopslider_status = 'Error occured while updating Slider '.$title.' !';
		$chopslider_status_class = 'error';
	};
	
}
?>