<?php
if( isset( $_POST['create-chopslider'] ) || isset( $_POST['save-edited-chopslider'] ) ) {
	include_once dirname( __FILE__ ) . "/chopslider-admin-form-handler.php";
}
?>
<?php
if(!empty ( $_GET['remove_chopslider'] ) ) {
	include_once dirname( __FILE__ ) . "/chopslider-admin-remove.php";
}
?>
<?php
if(!empty ( $_POST['chopslider-action'] ) ) {
	include_once dirname( __FILE__ ) . "/chopslider-bulk-actions.php";
}
?>
<?php
global $wpdb;
$chopslider_result = $wpdb->get_results('SELECT * FROM ' . CHOPSLIDER_TABLE_NAME . ' ORDER BY chopslider_id DESC'); 
$wpdb->flush();
?>
<?php
if($_GET['rebuild']=="ok") {
	$chopslider_status_class = 'updated';
	$chopslider_status = "All files were successfully regenerated and updated!";
}

?>

<div class="cs-logo"> <a href="http://www.idangero.us/cs/"><img src="<?php echo CHOPSLIDER_PLUGIN_URL?>images/admin/logo.png" /></a></div>
<div class="wrap cs-pane">
  <h2 class="cs-rc">Created Sliders</h2>
  <?php if ( !empty( $chopslider_status ) ) : ?>
  <div class="chopslider-status <?php echo $chopslider_status_class ?>">
    <h3><?php echo $chopslider_status ?></h3>
    <div class="chopslider-status-close">close</div>
  </div>
  <?php endif; ?>
  <?php if ( $chopslider_result ) { ?>
  <span id="file-viewer-path" style="display:none"><?php echo plugin_dir_url( __FILE__ )."chopslider-fileviewer.php" ?></span>
  <form id="chopslider-ba-form" method="post" action="">
    <table cellpadding="0" cellspacing="0" class="wp-list-table widefat">
      <thead class="cs-rc">
        <tr>
          <th class="check-column"><input type="checkbox" value="all" name="chopslider-id[]" /></th>
          <th class="cs-rc">Title</th>
          <th class="cs-rc">Integration</th>
          <th class="cs-rc">Images</th>
          <th class="cs-rc">Version</th>
          <th class="cs-rc">Created / Updated</th>
          <th class="cs-rc">Edit</th>
          <th class="cs-rc">Remove</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($chopslider_result as $single_chopslider) : ?>
        <tr>
          <td style="vertical-align:top"><input type="checkbox" value="<?php echo $single_chopslider -> chopslider_id ?>" name="chopslider-id[]" /></td>
          <td><?php echo $single_chopslider->title ?></td>
          <td style="white-space:nowrap">
          <strong>Shortcode:</strong><br />
          [chopslider id="<?php echo $single_chopslider -> chopslider_id ?>"]<br />
          <div style="height:10px"></div>
          <strong>Template tag:</strong><br />
          &lt;?php chop_slider(<?php echo $single_chopslider -> chopslider_id ?>) ?&gt;</td>
          
          <td>
		    <div class="cs-manage-thumbs">
			<?php 
			$chopslider_options = unserialize($single_chopslider->options);
			foreach ($chopslider_options['slides'] as $slide):
        $bgURL = $slide['image'];
        if (!empty($slide['videoService'])) $bgURL = CHOPSLIDER_PLUGIN_URL.'images/admin/video-slide.png';
			?>
            	<div style="background-image:url(<?php echo $bgURL?>)"></div>
            <?php 
			endforeach ?>
          	</div>  
          </td>
          
          <td style="text-align:center"><?php echo $single_chopslider->version ?></td>
          <td><?php echo $single_chopslider->created ?></td>
          <td style="text-align:center"><a href="?page=chopslider-edit-slider&amp;id=<?php echo $single_chopslider -> chopslider_id ?>"><img src="<?php echo CHOPSLIDER_PLUGIN_URL?>images/admin/icon-edit-black.png" /></a></td>
          <td style="text-align:center"><a href="?page=chopslider&amp;remove_chopslider=<?php echo $single_chopslider -> chopslider_id ?>" class="chopslider_remove"><img src="<?php echo CHOPSLIDER_PLUGIN_URL?>images/admin/icon-delete-black.png" /></a></td>
        </tr>
        <?php endforeach ?>
      </tbody>
      <tfoot>
        <tr>
          <td><input type="checkbox" value="all" name="chopslider-id[]" /></td>
          <td colspan="6"><select name="chopslider-action" style="width:150px">
              <option value="" selected="selected">Bulk Actions</option>
              <option value="copy">Copy</option>
              <option value="delete">Delete</option>
            </select>
            <input id="submit-chopslider-bulk-actions" name="chopslider-bulk-actions" type="submit" class="button-secondary" value="Apply" /></td>
        </tr>
      </tfoot>
    </table>
  </form>
  <p style="text-align:left"><a class="cs-rc cs-button-primary" href="?page=chopslider-add-slider">Add New Chop Slider</a></p>
  <?php }
  else {
  ?>
  <p>Seems to be you have not created Chop Sliders. Click the button bellow to create your first Chop Slider:</p>
  <p style="text-align:left"><a class="cs-button-primary cs-rc" href="?page=chopslider-add-slider">Create New Chop Slider</a></p>
  <?php } ?>
</div>
<div class="wrap cs-pane">
  <h2 class="cs-rc">Chop Slider Dashboard</h2>
  <div class="metabox-holder">
    
    <div class="cs-box" style="width:48%; float:left; margin-right:4%">
      <h3 class="cs-rc cs-title-s"><span>Plugin Settings</span></h3>
      <div class="inside">
        <form action="options.php" method="post">
          <div class="chopslider-settings">
            <?php settings_fields( 'chopslider_settings' );?>
            <?php do_settings_sections( 'general' ); ?>
          </div>
          <p class="submit" style="padding:0; margin-top:0">
            <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
          </p>
        </form>
      </div>
    </div>
    <div class="cs-box" style="width:48%; float:left">
      <h3 class="cs-rc cs-title-s"><span>Tutorial Videos</span></h3>
      <div class="inside">
        <p><strong>How To Create Chop Slider 3</strong><br />
          This small tutorial will show how to create awesome Wordpress slider with Chop Slider 3 Wordpress plugin and integrate it to post with template tag. <br />
          <a href="http://www.youtube.com/watch?v=Vh9E62VkUdg" target="_blank"><em>Watch this video</em></a> </p>
        <p><strong>Chop Slider 3 Widget</strong><br />
          This small tutorial will show how to create and integrate slider with Chop Slider 3 widget <br />
          <a href="http://youtu.be/o1rlkcwFrEA" target="_blank"><em>Watch this video</em></a> </p>
        
      </div>
    </div>
    <div style="clear:both">
    <div class="cs-box">
      <h3 class="cs-rc cs-title-s"><span>iDangero.us on Twitter</span></h3>
      <div class="inside">
        <ul id="chopslider-tweets">
        </ul>
      </div>
    </div>
    <div style="clear:both;"></div>
  </div>
</div>
