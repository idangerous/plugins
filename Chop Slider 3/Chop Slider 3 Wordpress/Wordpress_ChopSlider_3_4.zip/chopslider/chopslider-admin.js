// JavaScript Document
(function($){
	$(function(){
		//Helpers
		$.fn.cswpTransform = function(params) {
			return this.each(function(){
				var es = $(this)[0].style;
				if (params.transform) {
					es.webkitTransform = es.MsTransform = es.MozTransform = es.OTransform = es.transform = params.transform
				}
				if (params.time||params.time===0) {
					es.webkitTransitionDuration = es.MsTransitionDuration = es.MozTransitionDuration = es.OTransitionDuration = es.transitionDuration = params.time/1000+'s'
				}
				if (params.delay||params.delay===0) {
					es.webkitTransitionDelay = es.MsTransitionDelay = es.MozTransitionDelay = es.OTransitionDelay = es.transitionDelay = params.delay/1000+'s'
				}
				if (params.origin) {
					es.webkitTransformOrigin = es.MsTransformOrigin = es.MozTransformOrigin = es.OTransformOrigin = es.transformOrigin = params.origin
				}
				if (params.ease) {
					es.webkitTransitionTimingFunction = es.MsTransitionTimingFunction = es.MozTransitionTimingFunction = es.OTransitionTimingFunction = es.transitionTimingFunction = params.ease
				}
				es.webkitTransitionProperty = es.MsTransitionTransitionProperty = es.MozTransitionTransitionProperty = es.OTransitionProperty = es.transitionProperty = 'all'
				
			})
		};
		//Manage Page
		if ( $('.cs-manage-thumbs').length>0 ) {
			$('.cs-manage-thumbs div').each(function(index, element) {
                var index = $(this).index()
				$(this).cswpTransform({
					origin: 'left bottom',
					time:300
				})
				var a = $(this)
				setTimeout(function(){
					a.cswpTransform({
						origin: 'left bottom',
						transform: 'rotate('+index*10+'deg)',
						time:2300,
						delay: (a.parent().find('div').length - index)*50
					})
				},50)
				
            });	
			
		}
		//--
		
		var cswp = {};
		cswp.previewURL = false;
		cswp.skin = $('input[name="skin"]').val()
		
		//Sliders
		if ( $('.amb-slider-size').length>0 ) {
			$('.amb-slider-size').slider({
				min: 10,
				max: 300,
				value : $('input[name="ambilightSize"]').val(),
				slide : function( event, ui ) {
					$('input[name="ambilightSize"]').val( ui.value )
				},
				change : function() {
					cswp.reloadSlider()	
				}
			})	
			$('.amb-slider-colorIndex').slider({
				min: 0.1,
				max: 3,
				step: 0.05,
				value : $('input[name="colorIndex"]').val(),
				slide : function( event, ui ) {
					$('input[name="colorIndex"]').val( ui.value )
				},
				change : function() {
					cswp.reloadSlider()	
				}
			})	
			$('.amb-slider-fadeIndex').slider({
				min: 0.5,
				max: 2,
				step: 0.1,
				value : $('input[name="fadeIndex"]').val(),
				slide : function( event, ui ) {
					$('input[name="fadeIndex"]').val( ui.value )
				},
				change : function() {
					cswp.reloadSlider()	
				}
			})	
		}
		
		
		//Settings Tabs
		$('.cs-tabs-left a').click(function(e) {
            e.preventDefault()
			$('.cs-tabs-left .active').removeClass('active');
			$(this).parent().addClass('active');
			$('.cs-tabs-right > .active').removeClass('active');
			$('.cs-tabs-right > div').eq( $(this).parent().index() ).addClass('active')
        });
		
		//Sortable
		if($( ".cs-slides" ).length>0) {
			$( ".cs-slides" ).sortable({
				items: "li:not(.ui-state-disabled)",
				update : function(){
					cswp.reloadSlider()	
				}
			});
		}
		//Submit Form
		$('.submit-form').click(function(e) {
            e.preventDefault();
			if ($('.cs-slides-area li').length<3) {
				alert('You need to upload at least 2 slides');	
			}
			else $(this).parents('form').submit()
        });
		//Upload Slides
		$('.cs-add-button a').click(function(e) {
            e.preventDefault();
			tb_show('', 'media-upload.php?type=image&TB_iframe=true');
        });
		
		//Preview BGs
		$(document).on('click','a.switch-bg',function(e) {
            e.preventDefault();
			if ($(this).hasClass('reload-slider')) {
				cswp.reloadSlider();
				return;	
			}
			if ($(this).hasClass('bg-black')) $('.cs-preview-area').css({background:'#000'})
			if ($(this).hasClass('bg-white')) $('.cs-preview-area').css({background:'#fff'})
			if ($(this).hasClass('bg-grey')) $('.cs-preview-area').css({background:'#eee'})
        });
		
		//CS Icons
		$(document).on('click','.cs-t-remove', function(e){
			e.preventDefault()
			$(this).parents('li').remove()	;
			cswp.reloadSlider();
		})
		$(document).on('click','.cs-t-image', function(e){
			e.preventDefault()
			cswp.updateImage = $(this).parents('li').find('.cs-t-bg');
			tb_show('', 'media-upload.php?type=image&TB_iframe=true');
		})
		$(document).on('click','.cs-t-edit', function(e){
			e.preventDefault();
			e.stopPropagation();
			$('.cs-slide-popup').hide()	
			$(this).parents('li').find('.cs-slide-popup').show()	
		})
		$(document).on('click','html',function(){
			$('.cs-slide-popup').hide()	
		})
		$(document).on('click','.cs-slide-popup',function(e) {
            e.stopPropagation();
        });
		$(document).on('click','.cs-slides .cs-button-primary', function(e){
			e.preventDefault();
			$('.cs-slide-popup').hide();
			cswp.reloadSlider();	
		})
		
		//Image Uploader
		window.send_to_editor = function(html) {
			var url = $('img',html).attr('src');
			tb_remove();
			if (!cswp.updateImage) {
				var li = $('.cs-template').clone().removeClass('cs-template');
				li.find('.cs-t-bg').attr({src: url})
				li.find('input[name="image[]"]').val(url)
				li.insertBefore( $('.cs-slides .cs-add-button') )
			}
			else {
				var url = $('img',html).attr('src');
				cswp.updateImage.attr({src: url})
				cswp.updateImage.parent().find('input[name="image[]"]').val(url)
				cswp.updateImage = false;	
			}
			cswp.loadPreviewImage();
		}
		
		//Update Preview
		cswp.loadPreviewImage = function(){
			var url = $('.cs-slides li:eq(0) input[name="image[]"]').val()
			//Update Dimensions
			var image = new Image();
			image.onload = function(){
				if (cswp.autoSize()) {
					$('.cs-tab input[name="height"]').val(image.height)
					$('.cs-tab input[name="width"]').val(image.width)
				}
				if (!cswp.previewURL) {
					cswp.previewURL = url;
					cswp.reloadSlider(image)	
				}
				else {
					cswp.previewURL = url;
					cswp.reloadSlider(image)
				}
			};	
			image.src = url;
		}
		
		//Update Dimensions
		cswp.updateDimensions = function(image) {
			if (!image) {
				var image = new Image();
				var src = $('.cs-preview-area .cs3-slide:eq(0) img').attr('src');
				if (!src) {
					cswp.previewWidth = $('input[name="width"]').val();
					cswp.previewHeight = $('input[name="height"]').val();
					return;
				}
				image.src = src;	
			}
			if (cswp.autoSize()) {
				cswp.previewWidth = image.width;
				cswp.previewHeight = image.height;
			}
			else {
				cswp.previewWidth = $('input[name="width"]').val();
				cswp.previewHeight = $('input[name="height"]').val();
			}
			$('.cs-tab input[name="height"]').val(cswp.previewHeight)
			$('.cs-tab input[name="width"]').val(cswp.previewWidth)
		
		}
		//Re-loader slider
		cswp.reloadSlider = function(loadedImage){
			$('.cs-preview-area').html( $('.cs-preview-load-template').html() );
			if ( $('.cs-slides > li').length==5 ) {
				$('.cs-preview-area').html( '<p>Upload at least one image</p>' );
			}
			if ( $('.cs-slides > li').length<=6 ) {
				for (var i=0; i<2; i++) {
					var aLink = $('.cs-slides > li').eq(0).find('input[name="link[]"]').val();
					var aStart = '', aEnd = '';
					var image = $('.cs-slides > li').eq(0).find('input[name="image[]"]').val()
					var videoID = $('.cs-slides > li').eq(0).find('input[name="videoID[]"]').val()
					var videoService = $('.cs-slides > li').eq(0).find('input[name="videoService[]"]').val()
					if ($.trim(aLink).length>0) {
						aStart = '<a href="'+aLink+'">';
						aEnd = '</a>';	
					}
					if (typeof videoID=='undefined' ||  videoID.length==0) {
						$('.cs-preview-area .cs3').prepend('<div class="cs3-slide">'+aStart+'<img src="'+image+'">'+aEnd+'</div>');	
					}
					else {
						if (videoService=='youtube') {
							$('.cs-preview-area .cs3').prepend('<div class="cs3-slide cs3-video-slide"><div class="cs3-video"><iframe src="http://www.youtube.com/embed/'+videoID+'?wmode=opaque&rel=0" frameborder="0" allowfullscreen></iframe></div></div>');	
						}
						else {
							$('.cs-preview-area .cs3').prepend('<div class="cs3-slide cs3-video-slide"><div class="cs3-video"><iframe src="http://player.vimeo.com/video/'+videoID+'?title=0&amp;byline=0&amp;portrait=0&api=1" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe></div></div>');	
						}
					}
					//Captions
					var captionTitle="", captionText ="";
					captionTitle = $.trim( $('.cs-slides > li').eq(0).find('input[name="title[]"]').val() );
					if (captionTitle.length>0) captionTitle = '<div class="cs3-caption-title">'+captionTitle+'</div>';
					
					captionText = $.trim( $('.cs-slides > li').eq(0).find('textarea[name="text[]"]').val() );
					if (captionText.length>0) captionText = '<div class="cs3-caption-text">'+captionText+'</div>';
					
					var captionHTML = '<div class="cs3-caption">'+(captionTitle + captionText)+'</div>';
					$('.cs3-captions').prepend(captionHTML);
					//--
				}
			}
			else {
				for (var i=$('.cs-slides > li').length-6; i>=0; i--) {
					var image = $('.cs-slides > li').eq(i).find('input[name="image[]"]').val()
					var videoID = $('.cs-slides > li').eq(i).find('input[name="videoID[]"]').val()
					var videoService = $('.cs-slides > li').eq(i).find('input[name="videoService[]"]').val()
					//Links
					var aLink = $('.cs-slides > li').eq(i).find('input[name="link[]"]').val()
					var aStart = '', aEnd = '';
					if ($.trim(aLink).length>0) {
						aStart = '<a href="'+aLink+'">';
						aEnd = '</a>';	
					}
					//--
					if (typeof videoID == 'undefined' || videoID.length==0) {
						$('.cs-preview-area .cs3').prepend('<div class="cs3-slide">'+aStart+'<img src="'+image+'">'+aEnd+'</div>');	
					}
					else {
						if (videoService=='youtube') {
							$('.cs-preview-area .cs3').prepend('<div class="cs3-slide cs3-video-slide"><div class="cs3-video"><iframe src="http://www.youtube.com/embed/'+videoID+'?wmode=opaque&rel=0" frameborder="0" allowfullscreen></iframe></div></div>');	
						}
						else {
							$('.cs-preview-area .cs3').prepend('<div class="cs3-slide cs3-video-slide"><div class="cs3-video"><iframe src="http://player.vimeo.com/video/'+videoID+'?title=0&amp;byline=0&amp;portrait=0&api=1" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe></div></div>');	
						}
					}
					
					//Captions
					var captionTitle="", captionText ="";
					captionTitle = $.trim( $('.cs-slides > li').eq(i).find('input[name="title[]"]').val() );
					if (captionTitle.length>0) captionTitle = '<div class="cs3-caption-title">'+captionTitle+'</div>';
					
					captionText = $.trim( $('.cs-slides > li').eq(i).find('textarea[name="text[]"]').val() );
					if (captionText.length>0) captionText = '<div class="cs3-caption-text">'+captionText+'</div>';
					
					var captionHTML = '<div class="cs3-caption">'+(captionTitle + captionText)+'</div>';
					$('.cs3-captions').prepend(captionHTML);
					//--
				}
			}
			
			cswp.updateDimensions(loadedImage)
			window.cs3WP = $('.cs-preview-area .cs3')
			.css({width: cswp.previewWidth, height:cswp.previewHeight  })
			.cs3( cswp.sliderSettings() )
			
			$('.cs-preview-area .cs3-wrap')
			.css({width: cswp.previewWidth, height:cswp.previewHeight  })
			
			cswp.updateSkin()
			cswp.updateCaption()
			cswp.updateFS()
			$('.cs-preview-area').css({minWidth: cswp.previewWidth});
			if (cs3WP && cs3WP.support)
				$("#cs-support").html('3D Effects: '+cs3WP.support.threeD+'<br>2D Effects: '+cs3WP.support.css3+'<br>Canvas Effects: '+cs3WP.support.canvas+'<br>Touch Effects: '+cs3WP.support.touch+'')
		}
		
		//Slider Settings
		cswp.sliderSettings = function(){
			var ambilight = {
				enabled : false	
			};
			
			if ( $('select[name="ambilight"]').val()==='true' ) {
				ambilight.enabled = true;
				ambilight.size = $('input[name="ambilightSize"]').val();
				ambilight.colorIndex = $('input[name="colorIndex"]').val()
				ambilight.fadeIndex = $('input[name="fadeIndex"]').val()
			}
				
			var pagination = false;
			if ( $('select[name="pagination"]').val()==='true' ) {
				pagination = {
					container : '.cs-preview-area .cs3-pagination',
					hideOnStart : $('select[name="hideOnStart"]').val()==='true' ? true : false,
					showOnlyOnHover : $('select[name="showOnlyOnHover"]').val()==='true' ? true : false
				}
			}
			else {
				$('.cs-preview-area .cs3-pagination-wrap').remove()	
			}
			
			var navigation = false;
			if ( $('select[name="navigation"]').val()==='true' ) {
				navigation = {
					next : '.cs-preview-area .cs3-slide-next',
					prev : '.cs-preview-area .cs3-slide-prev',
					hideOnStart : $('select[name="hideOnStart"]').val()==='true' ? true : false,
					showOnlyOnHover : $('select[name="showOnlyOnHover"]').val()==='true' ? true : false
				}
			}
			else {
				$('.cs-preview-area .cs3-slide-next, .cs-preview-area .cs3-slide-prev').remove()	
			}
			
			var captions = false;
			if ( $('select[name="captions"]').val()==='true' ) {
				captions = {
					enabled : true,
					duration : $('input[name="captionsDuration"]').val(),
					type : $('select[name="captionsType"]').val(),
					multi : $('select[name="captionsMulti"]').val()==='true' ? true : false,
					multiDelay : $('input[name="multiDelay"]').val()
				}
			}
			else {
				$('.cs-preview-area .cs3-captions').remove()
			}
			
			var touch = false;
			if ( $('select[name="touch"]').val()==='true' ) {
				touch = {
					enabled : true,
					effect : $('select[name="touchEffect"]').val()
				}
			}
			var effects = [];
			//=====Effects===
			var effects;
			//Flat Effects
			if ($('#cs-e-flat .cs-effects-all input').is(':checked')) {
				effects.push('random-flat')
			}
			else {
				$('#cs-e-flat input').each(function(index, element) {
					if ($(this).is(':checked')) effects.push($(this).val())
				});
			}
			
			//2d Effects
			if ($('#cs-e-2d .cs-effects-all input').is(':checked')) {
				effects.push('random-2d')
			}
			else {
				$('#cs-e-2d input').each(function(index, element) {
					if ($(this).is(':checked')) effects.push($(this).val())
				});
			}
			
			//3d Effects
			if ($('#cs-e-3d .cs-effects-all input').is(':checked')) {
				effects.push('random-3d')
			}
			else {
				$('#cs-e-3d input').each(function(index, element) {
					if ($(this).is(':checked')) effects.push($(this).val())
				});
			}
			
			//Canvas Effects
			if ($('#cs-e-canvas .cs-effects-all input').is(':checked')) {
				effects.push('random-canvas')
			}
			else {
				$('#cs-e-canvas input').each(function(index, element) {
					if ($(this).is(':checked')) effects.push($(this).val())
				});
			}
				
			//--
			effects = effects.join(',');
			
			//Gallery
			var gallery = {
				enabled : $('select[name="gallery"]').val()==='true'? true : false,
				showCaptions : $('select[name="showCaptions"]').val()==='true'? true : false,
				trigger : '.cs-preview-area .cs3-fs-trigger',
				hideOnStart : $('select[name="hideOnStart"]').val()==='true' ? true : false,
				showOnlyOnHover : $('select[name="showOnlyOnHover"]').val()==='true' ? true : false
			}
			
			var s = {
				preloader : $('.cs-tab select[name="preloader"]').val()==='true' ? true : false	,
				autoplay: {
					enabled : $('select[name="autoplay"]').val()==='true' ? true : false,
					delay: $('input[name="autoplayDelay"]').val(),
					disableOnInteraction : 	$('select[name="disableOnInteraction"]').val()==='true' ? true : false
				},
				effects : effects,
				ambilight : ambilight,
				pagination : pagination,
				navigation : navigation,
				captions : captions,
				touch : touch,
				responsive: $('select[name="responsive"]').val(),
				gallery: gallery
			};
			
			return s;	
		}
		
		//Update Slider on field changes
		$('select[name="captions"], select[name="captionsType"], select[name="captionsMulti"], select[name="ambilight"], select[name="touch"], select[name="touchEffect"], select[name="navigation"], select[name="pagination"], select[name="hideOnStart"], select[name="showOnlyOnHover"], select[name="autoplay"], select[name="disableOnInteraction"], .cs-effects input, select[name="gallery"], select[name="showCaptions"], select[name="galleryColor"], select[name="galleryPosition"]').change(function(e) {
            cswp.reloadSlider();
        });
		$('input[name="autoplayDelay"], input[name="captionsDuration"], input[name="multiDelay"], input[name="ambilightSize"], input[name="colorIndex"] , input[name="fadeIndex"]').blur(function(){
			cswp.reloadSlider();
		});
		$('input[name="width"], input[name="height"]').blur(function(){
			if(!cswp.autoSize()) cswp.reloadSlider();
			else {
				$('input[name="width"]').val(cswp.previewWidth)	;
				$('input[name="height"]').val(cswp.previewHeight)	
			}
		})
		
		//Select Skins
		$('a.skin').click(function(e) {
            e.preventDefault()
			$('a.skin.active').removeClass('active');
			$(this).addClass('active');
			cswp.skin = $(this).data('skin');
			$('input[name="skin"]').val(cswp.skin);
			//cswp.updateSkin()
			cswp.reloadSlider();
        });
		cswp.updateSkin = function(){
			$('.cs-preview-area .cs3-wrap').removeAttr('class').addClass(cswp.skin).addClass('cs3-wrap')	
		}
		//Update FS
		cswp.updateFS = function(){
			if ($('select[name="gallery"]').val()==='true') {
				var style = 'cs3-fs-trigger-black'
				if ($('select[name="galleryColor"]').val()==='white') style = 'cs3-fs-trigger-white'
				
				var position = 'cs3-fs-trigger-right'
				if ($('select[name="galleryPosition"]').val()==='left') position = 'cs3-fs-trigger-left'
				
				$('.cs-preview-area .cs3-fs-trigger').addClass(style).addClass(position)
			}
			else {
				$('.cs-preview-area .cs3-fs-trigger').remove()	
			}
		}
		//Update Caption
		$('input[name="captionType"], input[name="captionColor"], input[name="captionPosition"], select[name="captionsMulti"]').change(function(e) {
			cswp.updateCaption();
        });
		cswp.updateCaption = function(){
			var multi = false;
			var captions = $('.cs-preview-area .cs3-captions');
			var cssClass = 'cs3-captions'
			if ($('select[name="captionsMulti"]').val()==='true') {
				multi = true;
				cssClass += ' cs3-multi-captions';	
			}
			multiType = $('input[name="captionType"]:checked').val()==='multi'
			//Caption Type
			if (multiType) cssClass+=' cs3-caption-multi';
			else cssClass+=' cs3-caption-single';
			
			//Caption Style
			if ( $('input[name="captionColor"]:checked').val()=='black' ){
				if (multiType) cssClass+=' cs3-caption-multi-black';
				else cssClass+=' cs3-caption-single-black';
			}
			
			//Caption Position
			if ( $('input[name="captionPosition"]:checked').val()=='left' ){
				if (multiType) cssClass+=' cs3-caption-multi-lt';
				else cssClass+=' ';
			}
			else {
				if (multiType) cssClass+=' ';
				else cssClass+=' cs3-caption-single-right';
			}
			captions.attr({class: cssClass})
		}
		
		//Auto Size
		$('#cs-autosize').change(function(e) {
            if (!$(this).is(':checked')) {
				$('.cs-input-disabled').removeClass('cs-input-disabled')	
			}
			else {
				$('input[name="width"], input[name="height"]').addClass('cs-input-disabled')	
			}
			cswp.reloadSlider();
        });
		cswp.autoSize = function(){
			var s = false;
			if ($('#cs-autosize').is(':checked')) s = true;
			return s;	
		}
		
		//Select / Deselect all effects
		$('.cs-effects-all input').change(function(){
			var checked = $(this).is(':checked');
			if (checked) $(this).parents('ul').find('input').attr('checked',true);
			else $(this).parents('ul').find('input').attr('checked',false);
		})
		$('.cs-effects li:not(.cs-effects) input').change(function(){
			var checked = $(this).is(':checked');
			if (!checked) $(this).parents('ul').find('.cs-effects-all input').attr('checked',false);
		})
		
		//Old Starts
		
		//File Viewer
		
		
		//Twitter
		if ($("#chopslider-tweets").length>0) {
			$("#chopslider-tweets").idTwitter({
				username : "chopslider",
				numberOfTweets : 6,
				loadingText : '<li class="tweets_load">Loading tweets...</li>',
				tweetFormat : '<li class="single-tweet">'
							+ '<p class="tweet-text">'
							+ '%tweetText'
							+ '</p>'
							+ '<p class="tweet-date">on %tweetDate</p>'
							+ '</li>'	
			})
		}
		//Status message
		$(".chopslider-status-close").click(function(){
			$(this).parent(".chopslider-status").slideUp(600)
		})
		//Chop Slider Bulk Actions
		$("input#submit-chopslider-bulk-actions").click(function(e){
			e.preventDefault();
			if ( $("select[name='chopslider-action']").val()=="delete" ) {
				if (confirm('Are you sure you want to remove all the selected Sliders?')) {
					$('#chopslider-ba-form').submit()
				}
			}
			else {
				$('#chopslider-ba-form').submit()
			}
		})
		$("#chopslider-ba-form input[name='chopslider-id[]'][value='all']").change(function(e){
			if($(this).is(":checked")) {
				$(this).parents("table").find("input[type='checkbox']").attr({'checked':'checked'})	
			}
			else {
				$(this).parents("table").find("input[type='checkbox']").removeAttr('checked')	
			}
		})
		//Single Select
		$("#chopslider-ba-form input[type='checkbox'][value!='all']").click(function(){
			$(this).parents('table').find("input[type='checkbox'][value='all']").removeAttr("checked")
		})
		//Delete Chop Slider
		$(".chopslider_remove").click(function(e){
			e.preventDefault();
			if (confirm('Are you sure you want to remove this Chop Slider?')) {
				document.location.href = $(this).attr('href')
			}
		})
		
		/* Load Slider on Edit Page */
		if (window.loadChopSlider) {
			(function(){
				var image = new Image();
				image.onload = function(){
					cswp.reloadSlider();
				};
				image.src = $('.cs-slides-area li:eq(0) img').attr('src');	
			})();
		}
		//Find Effects
		$('.cs-effects-all input').each(function(index, element) {
            if ($(this).is(':checked')) {
				$(this).parents('ul').find('li:not(.cs-effects-all) input').attr('checked', true);	
			}
        });
		
		/* Instagram API */
		$('.cs-instagram-popup .cs-button-primary').click(function(e) {
            e.preventDefault();
			var username = $('.cs-instagram-popup input[name="insta-username"]').val();
			var count = $('.cs-instagram-popup input[name="insta-count"]').val();
			if (username=='') {
				alert('Username must be not empty!');
				return;	
			}
			var id = false;
			if (count==0 || count=='') count = 5;
			$.getJSON(
				'https://api.instagram.com/v1/users/search?q='+username+'&access_token=229820329.f59def8.087f5453411a4a3f858c1eff477b1502&callback=?',
				{}, 
				function(data){
					id = data.data[0].id
					if (!id) alert('User not found!');
					else {
						$.getJSON(
							'https://api.instagram.com/v1/users/'+id+'/media/recent/?access_token=229820329.f59def8.087f5453411a4a3f858c1eff477b1502&callback=?',
							{}, 
							function(data){
								var images = data.data;
								if (images.length==0) {
									alert('There is no photos to load');
									return;
								}
								for (var i = 0; (i<count && i<images.length); i++) {
									var src = images[i].images.standard_resolution.url;
									var caption = '';
									if(images[i].caption && images[i].caption.text) caption = images[i].caption.text;
									//Insert Photo
									var li = $('.cs-template').clone().removeClass('cs-template');
									li.find('.cs-t-bg').attr({src: src});
									li.find('input[name="image[]"]').val(src);
									if (caption && caption.length>0) {
										li.find('textarea[name="text[]"]').val(caption)	
									}
									li.insertBefore( $('.cs-slides .cs-add-button') )
								}
								$('.cs-instagram-popup').hide();
								cswp.reloadSlider();
							}
						)	
					}
				}
			)
        });
		
		$('.cs-instagram-popup .cs-button-secondary').click(function(e) {
            e.preventDefault();
			$('.cs-instagram-popup').hide();
        });
		$('.cs-add-instagram-button').click(function(e) {
            e.preventDefault();
			$('.cs-instagram-popup').css({top:$(window).scrollTop()+100}).show()
			$('.cs-flickr-popup').hide()
        });
		/* Flickr API */
		$('.cs-flickr-popup .cs-button-primary').click(function(e) {
            e.preventDefault();
			var userID = $('.cs-flickr-popup input[name="flickr-id"]').val();
			var count = $('.cs-flickr-popup input[name="flickr-count"]').val();
			if (userID=='') {
				alert('User ID must be not empty!');
				return;
			}
			var id = false;
			if (count==0 || count=='') count = 5;
			$.getJSON(
				'http://api.flickr.com/services/rest/?method=flickr.people.getPublicPhotos&api_key=30a37e5dd95ab44d8e38443027a7c4e7&user_id='+userID+'&extras=description%2Curl_t%2Curl_l&format=json&jsoncallback=?',
				{}, 
				function(data){
					var images = data.photos.photo;
					if (images.length==0) {
						alert('There is no photos to load');
						return;	
					}
					for (var i =0; i<images.length && i<count; i++) {

						var src = images[i].url_l;
						var title = '';
						var caption = '';
						if(images[i].description._content.length>0) caption = images[i].description._content;
						if(images[i].title.length>0) title = images[i].title;
						//Insert Photo
						var li = $('.cs-template').clone().removeClass('cs-template');
						li.find('.cs-t-bg').attr({src: src});
						li.find('input[name="image[]"]').val(src);
						if (caption && caption.length>0) {
							li.find('textarea[name="text[]"]').val(caption)	
						}
						if (title && title.length>0) {
							li.find('input[name="title[]"]').val(title)	
						}
						li.insertBefore( $('.cs-slides .cs-add-button') )	
					}
					$('.cs-flickr-popup').hide();
					cswp.reloadSlider();
				}
			)
        });
		
		$('.cs-flickr-popup .cs-button-secondary').click(function(e) {
            e.preventDefault();
			$('.cs-flickr-popup').hide();
        });
		$('.cs-add-flickr-button').click(function(e) {
            e.preventDefault();
			$('.cs-flickr-popup').css({top:$(window).scrollTop()+100}).show();
			$('.cs-instagram-popup').hide()
        });

        /* Video APIs */
		$('.cs-youtube-popup .cs-button-primary').click(function(e) {
            e.preventDefault();
            var videoID = $('.cs-youtube-popup input[name="youtube-id"]').val()
            if (videoID.length==0) {
            	alert('Video ID must be not empty!')
            	return
            }
            //Insert Video
			var li = $('.cs-template').clone().removeClass('cs-template');
			li.find('.cs-t-bg').attr({src: chopSliderPluginURL+'images/admin/logo-youtube.png'});
			li.find('input[name="videoID[]"]').val(videoID);
			li.find('input[name="videoService[]"]').val('youtube');
			li.insertBefore( $('.cs-slides .cs-add-button') )
			$('.cs-youtube-popup').hide();
			$('select[name="responsive"] option[value="false"]').removeAttr('selected')
			$('select[name="responsive"] option[value="true"]').attr('selected', true)
			cswp.reloadSlider();			
            
        });
        $('.cs-vimeo-popup .cs-button-primary').click(function(e) {
            e.preventDefault();
            var videoID = $('.cs-vimeo-popup input[name="vimeo-id"]').val()
            if (videoID.length==0) {
            	alert('Video ID must be not empty!')
            	return
            }
            //Insert Video
			var li = $('.cs-template').clone().removeClass('cs-template');
			li.find('.cs-t-bg').attr({src: chopSliderPluginURL+'images/admin/logo-vimeo.png'});
			li.find('input[name="videoID[]"]').val(videoID);
			li.find('input[name="videoService[]"]').val('vimeo');
			li.insertBefore( $('.cs-slides .cs-add-button') )
			$('.cs-vimeo-popup').hide();
			$('select[name="responsive"] option[value="false"]').removeAttr('selected')
			$('select[name="responsive"] option[value="true"]').attr('selected', true)
			cswp.reloadSlider();			
            
        });
		
		$('.cs-youtube-popup .cs-button-secondary').click(function(e) {
            e.preventDefault();
			$('.cs-additional-popup').hide();
        });
		$('.cs-add-youtube-button').click(function(e) {
            e.preventDefault();
			$('.cs-additional-popup').hide()
			$('.cs-youtube-popup').css({top:$(window).scrollTop()+100}).show();
        });
        $('.cs-vimeo-popup .cs-button-secondary').click(function(e) {
            e.preventDefault();
			$('.cs-additional-popup').hide();
        });
		$('.cs-add-vimeo-button').click(function(e) {
            e.preventDefault();
			$('.cs-additional-popup').hide()
			$('.cs-vimeo-popup').css({top:$(window).scrollTop()+100}).show();
        });
	})
	
})(jQuery);
/*
iDangero.us jQuery Twitter Feed
------------------------
Version - 1.1
*/
(function($) {
	$.fn.idTwitter = function(a,callback) {
		var tweetContainer = this;
		if (tweetContainer.length==0) return;
		this.html(a.loadingText)
		$.getJSON("http://api.twitter.com/1/statuses/user_timeline.json?screen_name="+a.username+"&count="+a.numberOfTweets+"&include_entities=true&include_rts=true&callback=?",
		function(tweetData){
			tweetContainer.html("")
			$.each(tweetData, function(i,tweet) {
				var tweetDate = tweet.created_at.substr(0,20);
				var tweetText = tweet.text;
				for (var i =0; i<tweet.entities.user_mentions.length; i++) {
					var mentioned = tweet.entities.user_mentions[i].screen_name;
					tweetText = tweetText.replace('@'+mentioned,'<a href="http://twitter.com/'+mentioned+'">@'+mentioned+'</a>')	
				}
				for (var i =0; i<tweet.entities.urls.length; i++) {
					var uRL = tweet.entities.urls[i].url;
					tweetText = tweetText.replace(uRL,'<a href="'+uRL+'">'+uRL+'</a>')	
				}
				var readyTweet = a.tweetFormat.replace(/%username/g,a.username)
					readyTweet = readyTweet.replace(/%tweetDate/g,tweetDate)
					readyTweet = readyTweet.replace(/%tweetText/g,tweetText)
				tweetContainer.append(readyTweet);
			})
			if(callback) callback()
		})
	}
})(jQuery);