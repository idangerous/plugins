<?php
/**
 * ------- Chop Slider 3 Custom Template Tag ------- 
*/

function chop_slider($id) {
	global $wpdb;
	$cs_result = $wpdb->get_row('SELECT * FROM ' . CHOPSLIDER_TABLE_NAME . ' WHERE chopslider_id =' . $id);
	$wpdb->flush();
	
	if (!$cs_result) return;
		
	//JS
	global $chopslider_IDs;
	array_push($chopslider_IDs, $id);
	
	//Chop Slider's HTML
	echo getChopSliderHTML($cs_result);
	
}
?>