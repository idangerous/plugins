<div style="display:none;">
  <ul>
    <li class="cs-template"> 
      <img class="cs-t-bg">
      <div class="cs-t-icons"> <a href="#" title="Edit slide's caption and link " class="cs-t-edit"></a> <a href="#" title="Change image" class="cs-t-image"></a> <a href="#" title="Remove slide" class="cs-t-remove"></a> </div>
      <input type="hidden" name="image[]" />
      <input type="hidden" name="videoID[]" />
      <input type="hidden" name="videoService[]" />
      <div class="cs-slide-popup">
      	<div class="cs-popup-angle"></div>
        <p>Caption title:<br /><input type="text" name="title[]" /></p>
        <p>Caption text (HTML):<br /><textarea name="text[]" ></textarea></p>
        <p>Slide link:<br /><input name="link[]" type="text" /></p>
        <p><a href="#" class="cs-button-primary" style="font-size:12px">Save & Reload Slider</a></p>
      </div>
    </li>
  </ul>
</div>
<div style="display:none" class="cs-preview-load-template">
  <div class="cs-preview-options">
  	<a href="#" class="switch-bg bg-grey"><span></span></a>
    <a href="#" class="switch-bg bg-black"><span></span></a>
    <a href="#" class="switch-bg reload-slider"></a>
  </div>
  <div class="cs3-wrap">
    <div class="cs3">
      <div class="cs3-skin-border-1"></div>
      <div class="cs3-skin-border-2"></div>
      <div class="cs3-shadow"><div class="cs3-shadow-left"><div class="cs3-shadow-right"><div class="cs3-shadow-mid"></div></div></div></div>
      <div class="cs3-slide-prev"></div>
      <div class="cs3-slide-next"></div>
      <div class="cs3-fs-trigger"></div>
      <div class="cs3-pagination-wrap">
        <div class="cs3-pagination"></div>
      </div>
      <div class="cs3-captions"></div>
    </div>
  </div>
</div>

<div class="cs-instagram-popup cs-additional-popup">
	<h2 class="cs-rc">Load Instagram Photos</h2>
    <p><label><span>Instagram Username:</span> <input type="text" class="cs-text" name="insta-username"></label></p>
    <p><label><span>Photos to load:</span> <input type="text"  class="cs-text" value="5" size="3" name="insta-count"></label></p>
    <div><a href="#" class="cs-button-primary cs-rc">Load</a> <a href="#" class="cs-button-secondary cs-rc">Cancel</a></div>
</div>

<div class="cs-flickr-popup cs-additional-popup">
	<h2 class="cs-rc">Load Flickr Photos</h2>
    <p><label><span>Flickr Username:</span> <input type="text" class="cs-text" name="flickr-id"></label></p>
    <p><label><span>Photos to load:</span> <input type="text"  class="cs-text" value="5" size="3" name="flickr-count"></label></p>
    <div><a href="#" class="cs-button-primary cs-rc">Load</a> <a href="#" class="cs-button-secondary cs-rc">Cancel</a></div>
</div>

<div class="cs-youtube-popup cs-additional-popup">
  <h2 class="cs-rc">Add Youtube Video</h2>
    <p><label><span>Video ID:</span> <input type="text" class="cs-text" name="youtube-id"></label></p>
    <div><a href="#" class="cs-button-primary cs-rc">Add</a> <a href="#" class="cs-button-secondary cs-rc">Cancel</a></div>
</div>

<div class="cs-vimeo-popup cs-additional-popup">
  <h2 class="cs-rc">Add Vimeo Video</h2>
    <p><label><span>Video ID:</span> <input type="text" class="cs-text" name="vimeo-id"></label></p>
    <div><a href="#" class="cs-button-primary cs-rc">Add</a> <a href="#" class="cs-button-secondary cs-rc">Cancel</a></div>
</div>