<?php
header ("Content-Type:	application/javascript; charset=utf-8");

// Path to WordPress Root
$absolute_path = __FILE__;
$path_to_file = explode( 'wp-content', $absolute_path );
$path_to_wp = $path_to_file[0];

// Access to WordPress
require_once( $path_to_wp . '/wp-load.php' );
$id = $_GET['id'];
global $wpdb;
$cs_result = $wpdb->get_row('SELECT * FROM ' . CHOPSLIDER_TABLE_NAME . ' WHERE chopslider_id =' . $id); 
$wpdb->flush();
$cs = unserialize ($cs_result -> options);
?>
(function($){
	$(document).ready(function(){
    	var chopslider = $('.chopslider_id_<?php echo $id?>')
		window.chopslider<?php echo $id?> = chopslider.cs3({
			preloader : <?php echo $cs['preloader']?>,
			responsive : <?php echo $cs['responsive']?>,
            responsiveSetSize: true,
			autoplay : {
				enabled : <?php echo $cs['autoplay']?>,
				delay : <?php echo $cs['autoplayDelay']?>,
				disableOnInteraction : <?php echo $cs['disableOnInteraction']?>
                
			},
			effects : '<?php echo $cs['effects']?>',
            <?php
			if (!empty($cs['effectsGroupLock-support3d']) || !empty($cs['effectsGroupLock-support2d']) || !empty($cs['effectsGroupLock-supportCanvasNoCSS3']) ) {
			?><?php echo "\n"?>
			effectsGroupLock : {
				support3d : <?php echo( !empty($cs['effectsGroupLock-support3d']) ? "'".$cs['effectsGroupLock-support3d']."'" : 'false' )?>,<?php echo "\n"?>
				support2d : <?php echo( !empty($cs['effectsGroupLock-support2d']) ? "'".$cs['effectsGroupLock-support2d']."'" : 'false' )?>,<?php echo "\n"?>
				supportCanvasNoCSS3 : <?php echo( !empty($cs['effectsGroupLock-supportCanvasNoCSS3']) ? "'".$cs['effectsGroupLock-supportCanvasNoCSS3']."'" : 'false' )?><?php echo "\n"?>	
			},
            <?php } ?>
            
			ambilight : {
				enabled : <?php echo( $cs['ambilight']==='true' ? 'true' : 'false' )?>,<?php echo "\n"?>
                size : <?php echo( $cs['ambilight']==='true' ? $cs['ambilightSize'] : 'false' )?>,<?php echo "\n"?>
                colorIndex : <?php echo( (!empty( $cs['colorIndex'] )) ? $cs['colorIndex'] : 'false' )?>,<?php echo "\n"?>
				fadeIndex : <?php echo( (!empty( $cs['fadeIndex'] )) ? $cs['fadeIndex'] : 'false' )?>,<?php echo "\n"?>
            },
            gallery : {
				enabled : <?php echo( $cs['gallery']==='true' ? 'true' : 'false' )?>,<?php echo "\n"?>
                trigger : '.chopslider_id_<?php echo $id?> .cs3-fs-trigger',<?php echo "\n"?>
                showCaptions : <?php echo( $cs['showCaptions']==='true' ? 'true' : 'false' )?>,<?php echo "\n"?>
				hideOnStart : <?php echo $cs['hideOnStart']?>,
				showOnlyOnHover : <?php echo $cs['showOnlyOnHover']?><?php echo "\n"?>
            },
			touch : {
				enabled : <?php echo $cs['touch']?>,
				effect : '<?php echo $cs['touchEffect']?>'
			},
			captions : {
				enabled : <?php echo $cs['captions']?>,
				duration : <?php echo $cs['captionsDuration']?>,
				type : '<?php echo $cs['captionsType']?>',
				multi : <?php echo $cs['captionsMulti']?>,
				multiDelay : <?php echo $cs['multiDelay']."\n"?>
			},
            <?php if ($cs['pagination']==='true') { ?><?php echo "\n"?>
			pagination : {
				container : '.chopslider_id_<?php echo $id?> .cs3-pagination',
				hideOnStart : <?php echo $cs['hideOnStart']?>,
				showOnlyOnHover : <?php echo $cs['showOnlyOnHover']?><?php echo "\n"?>
			},
            <?php } ?>
            <?php if ($cs['navigation']==='true') { ?><?php echo "\n"?>
			navigation : {
				next : '.chopslider_id_<?php echo $id?> .cs3-slide-next',
				prev : '.chopslider_id_<?php echo $id?> .cs3-slide-prev',
				hideOnStart : <?php echo $cs['hideOnStart']?>,
				showOnlyOnHover : <?php echo $cs['showOnlyOnHover']?><?php echo "\n"?>
			},
            <?php } ?><?php echo "\n"?>
			callbacks : {
				onInit : function(cs3){
            		/*
            		<?php if ($cs['responsive']==='true') { ?><?php echo "\n"?>
                    if (cs3.params.responsive) {
                        resizeSlider(cs3)
                        if ('onorientationchange' in window) {
                            window.onorientationchange = function(){ resizeSlider(cs3,true) };
                        }
                        else {
                            $(window).resize(function(){ resizeSlider(cs3, false, true) });
                        }
                   	}
                    <?php } ?><?php echo "\n"?>
                    */
            		<?php if (!empty($cs['onInit'])) echo $cs['onInit'] ?><?php echo "\n"?>
				},
				onTransitionStart : function(){
					<?php if (!empty($cs['onTransitionStart'])) echo $cs['onTransitionStart'] ?><?php echo "\n"?>
				},
				onTransitionEnd : function(cs3){
                	<?php if ($cs['responsive']==='true') { ?><?php echo "\n"?>
                    //resizeSlider(cs3);
                    <?php } ?><?php echo "\n"?>
                    
					<?php if (!empty($cs['onTransitionEnd'])) echo $cs['onTransitionEnd'] ?><?php echo "\n"?>
				}
			}
		});
        
        <?php if ($cs['responsive']==='true') { ?><?php echo "\n"?>
        function resizeSlider(cs3, reInit, reAmbi) {
        	return
            if (cs3.isAnimating) return;
            if (cs3.support.touch && cs3.params.touch.enabled) chopslider.find('.cs3-active-slide').show(); 
            var image = chopslider.find('.cs3-active-slide img');
            chopslider.css({height: image.height()});
            if (cs3.support.touch && cs3.params.touch.enabled) {
                if(reInit) {
                    setTimeout(function(){
                        cs3.plugins.touch.init(cs3);
                        chopslider.find('.cs3-slide').hide();
                    },50)
                }
                else chopslider.find('.cs3-slide').hide();
            }
            if (cs3.params.ambilight.enabled && reAmbi) {
            	cs3.plugins.ambilight.onEnd(cs3)
            }
        }
        <?php } ?><?php echo "\n"?>
	})
})(jQuery);
