<?php
/**
 * ------- Chop Slider 3 Short Code ------- 
**/
class Chopslider_Shortcode {
	static $add_script;
	function init() {
		add_shortcode('chopslider', array(__CLASS__, 'handle_chopslider_shortcode'));
	}	
	function handle_chopslider_shortcode($atts) {
		extract(shortcode_atts(array( "id" => '' ), $atts));
		global $wpdb;
		$cs_result = $wpdb->get_row('SELECT * FROM ' . CHOPSLIDER_TABLE_NAME . ' WHERE chopslider_id =' . $id);
		if (!$cs_result) return;
		
		//JS
		global $chopslider_IDs;
		array_push($chopslider_IDs, $id);
		
		//Return Chopslider's HTML
		return getChopSliderHTML($cs_result);
	}
}
Chopslider_Shortcode::init();
?>