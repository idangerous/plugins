<?php
/*
Plugin Name: iDangero.us Chop Slider 3
Plugin URI: http://www.idangero.us/cs/
Description: Image slider with totally amazing and unique effects with realistic 3D transitions. 
Version: 3.4
Author: Vladimir Kharlampidi, The iDangero.us
Author URI: http://www.idangero.us/
*/

/*  
Copyright 2012-2013 Vladimir Kharlampidi, The iDangero.us  (email: info@idangero.us)
*/
define('CHOPSLIDER_VERSION_CORE','3.4');
define('CHOPSLIDER_VERSION_WP', '3.4');
define('CHOPSLIDER_PLUGIN_URL', plugin_dir_url( __FILE__ ));
global $wpdb;
define('CHOPSLIDER_TABLE_NAME', $wpdb->prefix . "chopslider3");
$wpdb->flush();

// Init Chop Slider admin menus and pages
add_action('admin_menu', 'chopslider_admin_menu');

// Init Chop Slider Settings
add_action('admin_init', 'chopslider_settings');
function chopslider_settings() {
	register_setting( 'chopslider_settings', 'chopslider-settings' );
	add_settings_section('chopslider_settings_section', 'Chop Slider Settings', 'chopslider_settings_html', 'general');
	add_settings_field('chopslider_remove_db', '<p>Remove ChopSlider database on plugin delete:</p><span class="cs-tip">Set to "Do not remove" if you are going to remove Chop Slider before update to the new version</span>', 'cs_setting_removeDB', 'general', 'chopslider_settings_section');
	add_settings_field('chopslider_permissions', '<p>Permissions:</p><span class="cs-tip">Switch to "Administrator" if you are using Multiple Sites and want to allow for the sites administrators to mananage sliders.</span>', 'cs_setting_permissions', 'general', 'chopslider_settings_section');
	
	$testOption = get_option('chopslider-settings');
	if(!is_array($testOption)) {
		add_option( 'chopslider-settings', Array('remove_db'=>1, 'permissions'=>'edit_plugins') );	
	}
}
function chopslider_settings_html() {
		
}
function cs_setting_removeDB() {
	$options = get_option('chopslider-settings');
	echo '<select name="chopslider-settings[remove_db]">
	<option value="1" '.($options['remove_db']==1 ? 'selected="selected"' : "").'>Remove</option>
	<option value="0" '.($options['remove_db']==0 ? 'selected="selected"' : "").'>Do not remove</option>
	</select>
	';
}
function cs_setting_permissions() {
	$options = get_option('chopslider-settings');
	echo '<select name="chopslider-settings[permissions]">
	<option value="edit_plugins" '.($options['permissions']=='edit_plugins' ? 'selected="selected"' : "").'>Super Admin</option>
	<option value="delete_pages" '.($options['permissions']=='delete_pages' ? 'selected="selected"' : "").'>Administrator</option>
	</select>
	';
}

// Chop Slider Admin Pages
function chopslider_admin_menu() {
	$opt = get_option('chopslider-settings');
	$role = $opt['permissions'];
    // Add a new top-level Chop Slider's page:
    $chop_slider_manage_page = add_menu_page('Chop Slider 3', 'Chop Slider 3', $role, 'chopslider', 'chopslider_manage_page', plugin_dir_url( __FILE__ )."images/admin/icon.png");
	add_action('admin_print_styles-' . $chop_slider_manage_page, 'chopslider_admin_init');
	
    // Add a submenu for the "Add New" page:
    $chop_slider_addnew_page = add_submenu_page('chopslider', 'Create New Chop Slider', 'Create New', $role, 'chopslider-add-slider', 'chopslider_addnew_page');
	add_action('admin_print_styles-' . $chop_slider_addnew_page, 'chopslider_medialibrary');
	
	// Add a submenu for the "Edit" page:
    $chop_slider_edit_page = add_submenu_page('null', 'Edit Chop Slider', 'Edit Chop Slider', $role, 'chopslider-edit-slider', 'chopslider_edit_page');
	add_action('admin_print_styles-' . $chop_slider_edit_page, 'chopslider_medialibrary');
	
}
// Scripts and Styles for all Custom Pages
function chopslider_admin_init(){
	wp_register_style('chopslider-admin.css', CHOPSLIDER_PLUGIN_URL . 'chopslider-admin.css', array(), CHOPSLIDER_VERSION_WP);
	wp_enqueue_style('chopslider-admin.css');
	wp_register_script('chopslider-admin.js', CHOPSLIDER_PLUGIN_URL . 'chopslider-admin.js', array('jquery', 'jquery-ui-core', 'jquery-ui-widget', 'jquery-ui-mouse', 'jquery-ui-sortable', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-slider'), CHOPSLIDER_VERSION_WP);
	wp_enqueue_script('chopslider-admin.js');

}
// Scripts and Styles for the Add and Edit pages with a medialibrary and TinyMCE
function chopslider_medialibrary() {
	chopslider_admin_init();
	
	wp_enqueue_script('media-upload');
	wp_enqueue_script('thickbox');
	wp_enqueue_script('jquery');
	wp_enqueue_style('thickbox');
	
	wp_register_script('idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.min.js', CHOPSLIDER_PLUGIN_URL . 'cs3/idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.min.js', array('jquery'));
	wp_enqueue_script('idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.min.js');
	
	wp_register_style('idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.css', CHOPSLIDER_PLUGIN_URL . 'cs3/idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.css', array(), CHOPSLIDER_VERSION_WP);
	wp_enqueue_style('idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.css');
	
	wp_register_style('jui.css', CHOPSLIDER_PLUGIN_URL . 'jqueryui/css/jui.css', array(), CHOPSLIDER_VERSION_WP);
	wp_enqueue_style('jui.css');
	
}

// ChopSlider Management (Home) Page
function chopslider_manage_page() {
    include_once dirname( __FILE__ ) . "/chopslider-admin-manage.php";
}
// Chop Slider "Add New" Page
function chopslider_addnew_page() {
    include_once dirname( __FILE__ ) . "/chopslider-admin-add.php";
}
// Chop Slider "Edit" Page
function chopslider_edit_page() {
    include_once dirname( __FILE__ ) . "/chopslider-admin-edit.php";
}

// New Data Table If Not Created
function chopslider_add_new_table() {
	global $wpdb;
	$cs_table_name = CHOPSLIDER_TABLE_NAME;
	if($wpdb->get_var("SHOW TABLES LIKE '$cs_table_name'") != $cs_table_name) {
		$sql = "CREATE TABLE " . $cs_table_name . " (
			  `chopslider_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
			  `title` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
			  `options` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
			  `version` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
			  `created` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
			)  CHARACTER SET utf8 COLLATE utf8_general_ci;";
		
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
};
chopslider_add_new_table();


/**
 * ------- Chop Slider custom Editor button ------- 
*/
function add_chopslider_button() {
   if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
     return;
   // Add only in Rich Editor mode
   if ( get_user_option('rich_editing') == 'true') {
     add_filter("mce_external_plugins", "add_chopslider_tinymce_plugin");
     add_filter('mce_buttons', 'register_chopslider_button');
   }
}
function register_chopslider_button($buttons) {
   array_push($buttons, "|", "chopslider");
   return $buttons;
}

function add_chopslider_tinymce_plugin($plugin_array) {
   $plugin_array['chopslider'] = CHOPSLIDER_PLUGIN_URL.'editor_plugin.js';
   return $plugin_array;
} 
add_action('init', 'add_chopslider_button'); 


/**
 * ------- Chop Slider Integration ------- 
*/
include('_shortcode.php');
include('_template_tag.php');
include('_widget.php');



/**
 * ------------------ Function to Get HTML Content of Slides ------------------- 
*/
function getChopSliderHTML($res) {
	$cs = unserialize($res->options);
	$imageSlidesLength = 0;
	foreach($cs['slides'] as $slide) {
		if (empty($slide['videoID'])) $imageSlidesLength++;
	}	
	if ($cs['responsive']==='false') {
		$style = 'style="width:'.$cs['width'].'px; height:'.$cs['height'].'px" ';	
	}
	else {
		$containerHeight = '';
		if ($imageSlidesLength==0) $containerHeight = 'height:'.$cs['height'].'px';
		$style = 'style="max-width:'.$cs['width'].'px; margin-left:auto; margin-right:auto;'.$containerHeight.'"';	
	}
	$html = '<div class="cs3-wrap '.$cs['skin'].'"><div '.$style.' class="cs3 chopslider_id_'.$res->chopslider_id.'">
	';
	//Slides
	foreach($cs['slides'] as $slide) {
		$link = $slide['link'];
		$aStart = '';
		$aEnd = '';
		$videoService = $slide['videoService'];
		if (!empty($link)) {
			$aStart = '<a href="'.$link.'">';
			$aEnd = '</a>';
		}
		if ( empty($videoService) ) {
			$html.='<div class="cs3-slide">'.$aStart.'<img src="'.$slide['image'].'" />'.$aEnd.'</div>';
		}
		else {
			if ($videoService=='youtube'){
				$html.='<div class="cs3-slide cs3-video-slide"><div class="cs3-video"><iframe src="http://www.youtube.com/embed/'.$slide['videoID'].'?wmode=opaque&rel=0" frameborder="0" allowfullscreen></iframe></div></div>';
			}
			if ($videoService=='vimeo'){
				$html.='<div class="cs3-slide cs3-video-slide"><div class="cs3-video"><iframe src="http://player.vimeo.com/video/'.$slide['videoID'].'?title=0&amp;byline=0&amp;portrait=0&api=1" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe></div></div>';
			}
		}
	}
	//Skin Borders
	$html .='
	  <div class="cs3-skin-border-1"></div>
      <div class="cs3-skin-border-2"></div>
	  ';
	if ($cs['skin']=='cs3-skin-5') {
		$html .='
		  <div class="cs3-shadow"><div class="cs3-shadow-left"><div class="cs3-shadow-right"><div class="cs3-shadow-mid"></div></div></div></div>
		  ';	
		}
	//Controls
	if ($cs['navigation']==='true') {
		$html .='
		  <div class="cs3-slide-prev"></div>
		  <div class="cs3-slide-next"></div>
		';
	}
	if ($cs['pagination']==='true') {
		$html .='
		  <div class="cs3-pagination-wrap">
			<div class="cs3-pagination"></div>
		  </div>
		';
	}
	//Gallery
	if ($cs['gallery']==='true') {
		$fsColor = 'cs3-fs-trigger-black';
		if ($cs['galleryColor']==='white') $fsColor = 'cs3-fs-trigger-white';
		$fsPosition = 'cs3-fs-trigger-right';
		if ($cs['galleryColor']==='left') $fsPosition = 'cs3-fs-trigger-left';
		
		$html .='
		  <div class="cs3-fs-trigger '.$fsColor.' '.$fsPosition.' "></div>
		';
	}
	//Captions
	if ($cs['captions']==='true') {
		//Caption Style Classes
		$multi = false;
		$class = '';
		
		if ($cs['captionType']==='multi') {
			$class.=' cs3-caption-multi';
			$multi = true;
		}
		else $class.=' cs3-caption-single';
		
		if ($cs['captionColor']==="black") {
			if ($multi) $class.=' cs3-caption-multi-black';
			else $class.=' cs3-caption-single-black';	
		}
		
		if ( $cs["captionPosition"]==='left' ){
			if ($multi) $class.=' cs3-caption-multi-lt';
			else $class.=' ';
		}
		else {
			if ($multi) $class.=' ';
			else $class.=' cs3-caption-single-right';
		}
		
		$html.='<div class="cs3-captions '.$class.'">';
		foreach($cs['slides'] as $slide) {
			$title = "";
			$text = "";
			if (!empty($slide['title'])) $title = '<div class="cs3-caption-title">'.$slide['title'].'</div>';
			if (!empty($slide['text'])) $text = '<div class="cs3-caption-text">'.$slide['text'].'</div>';
			$html.='<div class="cs3-caption">'.$title.$text.'</div>';	
		}
		$html.='</div>';
	}
	
	$html .='</div></div>';
	return $html;
	
};

/* Print Styles */
add_action('wp_print_styles', 'print_frontend_cs3_styles');
function print_frontend_cs3_styles() {
	wp_register_style('idangerous.chopslider-' . CHOPSLIDER_VERSION_CORE . '.css', CHOPSLIDER_PLUGIN_URL . 'cs3/idangerous.chopslider-' . CHOPSLIDER_VERSION_CORE . '.css', array(), CHOPSLIDER_VERSION_WP);
	wp_enqueue_style('idangerous.chopslider-' . CHOPSLIDER_VERSION_CORE . '.css');
}


/* Print Chop Slider Scripts in Footer */
$chopslider_IDs = array();
add_action ('wp_footer', 'print_chopslider_scripts');
function print_chopslider_scripts() {
	global $chopslider_IDs;
	if (count($chopslider_IDs) == 0) return;
	array_unique($chopslider_IDs);	
	$i=0;
	foreach($chopslider_IDs as $id) {
		$i++;
		if ($i==1) {
			wp_register_script('idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.min.js', CHOPSLIDER_PLUGIN_URL . 'cs3/idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.min.js', array('jquery'));
			wp_print_scripts('idangerous.chopslider-'.CHOPSLIDER_VERSION_CORE.'.min.js');
		}
		wp_register_script('chopslider3_script_'.$id.'.js', CHOPSLIDER_PLUGIN_URL . 'get_script/?id='.$id, array('jquery'), $moover_result->version);
		wp_print_scripts('chopslider3_script_'.$id.'.js');
	}
}
?>