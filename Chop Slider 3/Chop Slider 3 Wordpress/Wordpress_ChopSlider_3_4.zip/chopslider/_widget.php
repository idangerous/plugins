<?php
/**
 * ------- Chop Slider Widget ------- 
*/
class ChopSlider extends WP_Widget {
	/** constructor */
	function ChopSlider() {
		parent::WP_Widget( 
			false, 
			$name = 'Chop Slider 3', 
			array('description' => "Add Chop Slider 3 as a widget." ) 
		);
	}
	/** @see WP_Widget::widget */
	function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title; 
		global $wpdb;
		$cs_result = $wpdb->get_row('SELECT * FROM ' . CHOPSLIDER_TABLE_NAME . ' WHERE chopslider_id =' . $instance['id']);
		$wpdb->flush();
		if ($cs_result) {
			//JS
			global $chopslider_IDs;
			array_push($chopslider_IDs, $instance['id']);
			
			//Chop Slider's HTML
			echo getChopSliderHTML($cs_result);
		}
		echo $after_widget;
	}
	
	/** @see WP_Widget::update */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['id'] = strip_tags($new_instance['id']);
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}

	/** @see WP_Widget::form */
	function form( $instance ) {
		if ( $instance ) {
			$id = esc_attr( $instance[ 'id' ] );
			$title = esc_attr( $instance[ 'title' ] );
		}
		else {
			$id = 0;
			$title = __( 'New title', 'text_domain' );
		}
		?>
        <p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>Select Slider: <br />
        <select name="<?php echo $this->get_field_name('id'); ?>">
        <?php
		global $wpdb;
		$chopslider_result = $wpdb->get_results('SELECT chopslider_id, title FROM ' . CHOPSLIDER_TABLE_NAME . ' ORDER BY chopslider_id DESC'); 
		foreach ($chopslider_result as $single_chopslider){
			if ( $single_chopslider -> chopslider_id == $id) $selected = 'selected = "selected"';
			else $selected = '';
		?>	
            <option <?php echo $selected ?> value="<?php echo $single_chopslider -> chopslider_id ?>"><?php echo $single_chopslider -> title ?></option>
        <?php } ?>
        </select>
		</p>
        
		<?php 
	}

}
// register ChopSlider widget
add_action( 'widgets_init', create_function( '', 'return register_widget("ChopSlider");' ) );
?>