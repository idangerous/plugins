<script>
  window.chopSliderPluginURL = '<?php echo CHOPSLIDER_PLUGIN_URL ?>'
</script>
<div class="wrap chopslider-form">
  <h2 class="cs-rc">Create New Chop Slider</h2>
  <p class="cs-return">&larr; <a href="admin.php?page=chopslider">Return to Chop Slider 3 dashboard</a></p>
  <form method="post" action="admin.php?page=chopslider" id="chopslider-addnew-form">
    <h3 class="cs-rc cs-title-settings">Upload Slides/Images</h3>
    <div class="cs-box cs-slides-area-box">
      <div class="inside">
        <div class="cs-slides-area">
          <ul class="cs-slides">
            <li class="cs-add-button cs-rc ui-state-disabled"><a href="#">Add<br />
              Slide</a></li>
            <li class="cs-add-instagram-button cs-rc ui-state-disabled"><a href="#"></a></li>
            <li class="cs-add-flickr-button cs-rc ui-state-disabled"><a href="#"></a></li>
            <li class="cs-add-youtube-button cs-rc ui-state-disabled"><a href="#"></a></li>
            <li class="cs-add-vimeo-button cs-rc ui-state-disabled"><a href="#"></a></li>
          </ul>
          <div class="clear"></div>
          <p style="margin:10px 0 0 0; font-size:12px">* Use Drag & Drop for re-ordering</p>
        </div>
      </div>
    </div>
    <h3 class="cs-rc cs-title-settings">Slider Preview</h3>
    <div class="cs-preview-area">
      <p>Upload at least one image</p>
    </div>
    <h3 class="cs-rc cs-title-settings">Slider Settings</h3>
    <div class="cs-tabs-left">
      <div class="active first"><a href="#">Title</a></div>
      <div><a href="#">Visual Appearence</a></div>
      <div><a href="#">Effects</a></div>
      <div><a href="#">Autoplay</a></div>
      <div><a href="#">Navigation / Pagination</a></div>
      <div><a href="#">Captions</a></div>
      <div><a href="#">Full Screen Gallery</a></div>
      <div><a href="#">Ambient Light</a></div>
      <div><a href="#">Touch</a></div>
      <div style="border-bottom:none;" class="last"><a href="#">Callbacks</a></div>
    </div>
    <div class="cs-tabs-right">
      <div class="cs-tab active">
      	<h3 class="cs-rc cs-tab-title">Slider Title</h3>
        <p><span>Title:</span>
          <span class="cs-form-right">
          <input type="text" name="slider-title" value="My Chop Slider" class="cs-text" size="" />
          
          </span>
          </p>
      </div>	
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Visual Appearence / Skins</h3>
        <p><span>Dimension:</span>
          <span class="cs-form-right">
          <input type="checkbox" value="true" name="autoSize" id="cs-autosize" checked="checked" /> Detect automatically<br />
          <input type="text" name="width" value="900" class="cs-text cs-input-disabled" size="4" />
          x
          <input type="text" name="height" value="300" class="cs-text cs-input-disabled" size="4" />
          px
          </span>
          </p>
        <p><span>Responsive:
              <i>Set to "Responsive" if you are you going to use slider in responsive layout.</i></span>
          <select name="responsive">
            <option selected="selected" value="false">Not responsive</option>
            <option value="true">Responsive</option>
          </select>
        </p>
        <p><span>Preloader:</span>
          <select name="preloader">
            <option selected="selected" value="true">Enabled</option>
            <option value="false">Disabled</option>
          </select>
          <select name="preloadOnlyFirst">
            <option selected="selected" value="false">All</option>
            <option value="true">Only first</option>
          </select>
        </p>
        Visual skin:<br />
        <div>
          <a class="skin active" data-skin="cs3-skin-no" href="#"><b>Default Skin</b><i></i></a>
          <a class="skin" data-skin="cs3-skin-1" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-1.jpg" /><b>Black Frame</b><i>For 2D, Flat and Canvas effects</i></a>
          <a class="skin" data-skin="cs3-skin-2" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-2.jpg" /><b>White Frame</b><i>For 2D, Flat and Canvas effects</i></a>
          <a class="skin" data-skin="cs3-skin-3" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-3.jpg" /><b>Woodback</b><i>Looks good with Canvas effects and "flat" 3D effects</i></a>
          <a class="skin" data-skin="cs3-skin-4" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-4.jpg" /><b>Device</b><i>Good for use with Ambient Light</i></a>
          <a class="skin" data-skin="cs3-skin-5" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-5.jpg" /><b>3D Skin</b><i>Good for use with volume 3D effects</i></a>
          <a class="skin" data-skin="cs3-skin-6" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-6.jpg" /><b>Magazine</b><i>Good for use with "Single-area" caption on the left</i></a>
          <a class="skin" data-skin="cs3-skin-7" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-7.jpg" /><b>Metall</b><i>For 2D, Flat and Canvas effects</i></a>
          <a class="skin" data-skin="cs3-skin-8" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-8.jpg" /><b>Pink</b><i>For 2D, Flat and Canvas effects</i></a>
          <a class="skin" data-skin="cs3-skin-9" href="#"><img src="<?php echo plugin_dir_url( __FILE__ )  ?>images/admin/skin-9.jpg" /><b>Pure White</b><i>For usage with light-color images</i></a>
          <div class="clear"></div>
          <input type="hidden" name="skin" value="cs3-skin-no" />
        </div>
      </div>
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Effects</h3>
        <ul class="cs-effects" id="cs-e-flat">
          <li class="cs-effects-title">Flat Effects</li>
          <li><label><input type="checkbox" checked="checked" name="e-flat[]" value="bricks" />Bricks</label></li>
          <li><label><input type="checkbox" checked="checked" name="e-flat[]" value="blinds_h" />Horizontal Blinds</label></li>
          <li><label><input type="checkbox" checked="checked" name="e-flat[]" value="blinds_v" />Vertical Blinds</label></li>
          <li><label><input type="checkbox" checked="checked" name="e-flat[]" value="zip" />Zip</label></li>
          <li><label><input type="checkbox" checked="checked" name="e-flat[]" value="fade" />Fade</label></li>
          <li class="cs-effects-all"><label><input type="checkbox" checked="checked" name="e-flat[]" value="random-flat" /> Choose all</label></li>
        </ul>
        <ul class="cs-effects" id="cs-e-2d">
          <li class="cs-effects-title">2D Effects</li>
          <li><label><input type="checkbox" name="e-2d[]" value="reveal" />Reveal</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="smear" />Smear</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="slide_h" />Horizontal Slide</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="slide_v" />Vertical Slide</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="zip_h" />Horizontal Zip</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="zip_v" />Vertical Zip</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="gravity" />Gravity</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="bulb" />Bulb</label></li>
          <li><label><input type="checkbox" name="e-2d[]" value="morpher" />Morpher</label></li>
          <li class="cs-effects-all"><label><input type="checkbox" name="e-2d[]" value="random-2d" />Choose all</label></li>
        </ul>
        
        <ul class="cs-effects" id="cs-e-3d">
          <li class="cs-effects-title">3D Effects</li>
          <li><label><input type="checkbox" name="e-3d[]" value="turn" />Turn</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="panels_h" />Horizontal Panels</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="panels_v" />Vertical Panels</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="polaroid" />Polaroid</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="bricks3d" />3D Bricks</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="tiles3d" />3D Tiles</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="flip_h_single" />Horizontal Single-flip</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="flip_h_multi" />Horizontal Multi-flip</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="flip_v_single" />Vertical Single-flip</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="flip_v_multi" />Vertical Multi-flip</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="flip_random" />Random Flip</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_v_1" />Vertical Blocks 1</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_v_2" />Vertical Blocks 2</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_v_3" />Vertical Blocks 3</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_v_4" />Vertical Blocks 4</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_v_5" />Vertical Blocks 5</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_v_6" />Vertical Blocks 6</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_v_7" />Vertical Blocks 7</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_h_1" />Horizontal Blocks 1</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_h_2" />Horizontal Blocks 2</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="blocks_h_3" />Horizontal Blocks 3</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="cube" />Cube</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="paper_h" />Horizontal Paper</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="paper_v" />Vertical Paper</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="galaxy" />Galaxy</label></li>
          <li><label><input type="checkbox" name="e-3d[]" value="explosion" />Explosion</label></li>
          
          <li class="cs-effects-all"><label><input type="checkbox" name="e-3d[]" value="random-3d" />Choose all</label></li>
        </ul>
        
        <ul class="cs-effects" id="cs-e-canvas">
          <li class="cs-effects-title">Canvas Effects</li>
          <li><label><input type="checkbox" name="e-canvas[]" value="circle_reveal" />Circle Reveal</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="lines" />Lines</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="aquarium" />Aquarium</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="razor" />Razor</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="burn" />Color Burn</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="melt" />Melt</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="roll" />Rollover</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="puzzles" />Puzzles</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="diamonds" />Diamonds</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="circles" />Circles</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="brush" />Paint Brush</label></li>
          <li><label><input type="checkbox" name="e-canvas[]" value="typewriter" />Typewriter</label></li>
          <li class="cs-effects-all"><label><input type="checkbox" name="e-canvas[]" value="random-canvas" />Choose all</label></li>
        </ul>
        <div style="clear:both"></div>
        <h3 class="cs-rc cs-tab-title">Effects Support-Lock</h3>
        <p>You can lock effects groups depending on browser support.</p>
        <p><span>Lock effects for browsers <strong>with 3D support</strong>:</span>
          <span class="cs-form-right">
          <input type="checkbox" name="effectsGroupLock-support3d[]" value="threeD" /> 3D &nbsp;&nbsp;&nbsp; <input type="checkbox" name="effectsGroupLock-support3d[]" value="canvas" /> Canvas<br />
          <input type="checkbox" name="effectsGroupLock-support3d[]" value="twoD" /> 2D &nbsp;&nbsp;&nbsp; <input type="checkbox" name="effectsGroupLock-support3d[]" value="flat" /> Flat
          </span>
        </p>
        <p><span>Lock effects for browsers <strong>with 2D support</strong> and <strong>without 3D support</strong>:</span>
          <span class="cs-form-right">
          <input type="checkbox" name="effectsGroupLock-support2d[]" value="canvas" /> Canvas<br />
          <input type="checkbox" name="effectsGroupLock-support2d[]" value="twoD" /> 2D &nbsp;&nbsp;&nbsp; <input type="checkbox" name="effectsGroupLock-support2d[]" value="flat" /> Flat
          </span>
        </p>
        <p><span>Lock effects for browsers <strong>with Canvas support</strong> and <strong>without CSS3 (2D and 3D) support</strong>:</span>
          <span class="cs-form-right">
           <input type="checkbox" name="effectsGroupLock-supportCanvasNoCSS3[]" value="flat" /> Flat &nbsp;&nbsp;&nbsp; <input type="checkbox" name="effectsGroupLock-supportCanvasNoCSS3[]" value="canvas" /> Canvas
          
          </span>
        </p>
        <h3 class="cs-rc cs-tab-title">Your browser support</h3>
        <p id="cs-support">Upload images to load the slider for support detection.</p>
      </div>
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Autoplay</h3>
        <p><span>Autoplay:</span>
          <select name="autoplay">
            <option value="false" selected="selected">Disabled</option>
            <option value="true">Enabled</option>
          </select>
        </p>
        <p><span>Autoplay delay:</span>
          <input type="text" name="autoplayDelay" value="5000" class="cs-text" size="4" />
          ms</p>
        <p><span>Disable autoplay on interraction:
              <i>If "Disable" then autoplay will be disabled after clicking on control elements like navigation/pagination.</i></span>
          <select name="disableOnInteraction">
            <option selected="selected" value="true" >Disable</option>
            <option value="false">Do not disable</option>
          </select>
        </p>
      </div>
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Slider Controls - Navigation / Pagination</h3>
        <p><span>Navigation arrows:</span>
          <select name="navigation">
            <option value="false">Disabled</option>
            <option value="true" selected="selected">Enabled</option>
          </select>
        </p>
        <p><span>Pagination:</span>
          <select name="pagination">
            <option value="false">Disabled</option>
            <option value="true" selected="selected">Enabled</option>
          </select>
        </p>
        <p><span>Hide controls on transition start:</span>
          <select name="hideOnStart">
            <option value="true">Hide</option>
            <option selected="selected" value="false">Do not hide</option>
          </select>
        </p>
        <p><span>Show controls only on hover:</span>
          <select name="showOnlyOnHover">
            <option value="true">Enabled</option>
            <option value="false" selected="selected">Disabled</option>
          </select>
        </p>
      </div>
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Captions</h3>
        <p><span>Captions:</span>
          <select name="captions">
            <option value="true" selected="selected">Enabled</option>
            <option value="false">Disabled</option>
          </select>
        </p>
        <p><span>Duration of caption animation:</span>
          <input name="captionsDuration" value="300" type="text" class="cs-text" size="4" />
          ms</p>
        <p><span>Type:
              <i>Direction of captions' animation - vertical or horizontal</i></span>
          <select name="captionsType">
            <option value="vertical">Vertical</option>
            <option value="horizontal" selected="selected">Horizontal</option>
          </select>
        </p>
        <p><span>Multi Captions:</span>
          <select name="captionsMulti">
            <option value="true" selected="selected">Enabled</option>
            <option value="false">Disabled</option>
          </select>
        </p>
        <p><span>Delay between multi captions:</span>
          <input name="multiDelay" value="100" type="text" class="cs-text" size="4" />
          ms</p>
        <p><span>Caption visual type:
              <i>Use "Single-area" type only with disabled Multi captions</i></span>
          <span class="cs-form-right">
          <input type="radio" name="captionType" value="multi" checked="checked" /> Divided title and description<br />
          <input type="radio" name="captionType" value="single" /> Single-area for title and description</span>
          </p>
        <p><span>Caption style:</span>
          <span class="cs-form-right">
          <input type="radio" name="captionColor" value="black" checked="checked" /> White text on black<br />
          <input type="radio" name="captionColor" value="white" /> Black text on white</span>
          </p>
        <p><span>Caption position:</span>
          <span class="cs-form-right">
          <input type="radio" name="captionPosition" value="left" checked="checked" /> Left-top for divided visual type (or left-side for single visual stype)<br />
          <input type="radio" name="captionPosition" value="right" /> Left-bottom for divided visual type (or right-side for single visual stype)</span>
          </p>
      </div>
      
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Full Screen Gallery</h3>
        <p><span>Gallery:</span>
          <select name="gallery">
            <option value="true">Enabled</option>
            <option selected="selected" value="false">Disabled</option>
          </select>
        </p>
        <p><span>Captions: <i>Set to Disabled if you want to hide captions in full screen gallery</i></span>
          <select name="showCaptions">
            <option value="true" selected="selected">Enabled</option>
            <option value="false">Disabled</option>
          </select>
        </p>
        <p><span>Gallery-switch style: <i>Set to Disabled if you want to hide captions in full screen gallery</i></span>
          <select name="galleryColor">
            <option value="black" selected="selected">Black</option>
            <option value="white">White</option>
          </select>
        </p>
        <p><span>Gallery-switch position: <i>Set to Disabled if you want to hide captions in full screen gallery</i></span>
          <select name="galleryPosition">
            <option value="right" selected="selected">Right</option>
            <option value="left">Left</option>
          </select>
        </p>
        
      </div>
      
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Chop Slider Ambient Light</h3>
        <p><span>Ambient Light:</span>
          <select name="ambilight">
            <option value="true">Enabled</option>
            <option selected="selected" value="false">Disabled</option>
          </select>
        </p>
        <p><span>Ambient Light size:
              <i>Size of ambient light in px. Recommended value is from 40 to 100 pixels</i></span>
          
          <span class="amb-slider-size"></span> 
          <input name="ambilightSize" value="50" type="text" class="cs-text" readonly="readonly" size="4" />
          px</p>
          
        <p><span>Color Index:
              <i>The larger this number the brighter the Ambient Light.</i></span>
          <span class="amb-slider-colorIndex"></span> 
          <input name="colorIndex" value="1.5" type="text" class="cs-text" readonly="readonly" size="4" />
          </p>
          
        <p><span>Fade Index:
              <i>The larger this number the stronger the Ambient Light fade.</i></span>
          
          <span class="amb-slider-fadeIndex"></span> 
          <input name="fadeIndex" value="1.3" type="text" class="cs-text"  readonly="readonly" size="4" />
          </p>
      </div>
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Chop Slider Touch</h3>
        <p><span>Chop Slider Touch:
              <i>Set to "Enabled" if you want to enable special effects for touch devices</i></span>
          <select name="touch">
            <option value="true" >Enabled</option>
            <option value="false" selected="selected">Disabled</option>
          </select>
        </p>
        <p><span>Touch Effect:
              <i>Special effect only for touch devices</i></span>
          <select name="touchEffect">
            <option value="cube">Cube</option>
            <option value="flip-s">Flip</option>
            <option value="flip-m">Multi Flip</option>
            <option value="slide-s" selected="selected">Slide</option>
            <option value="slide-m">Multi Slide</option>
          </select>
        </p>
      </div>
      <div class="cs-tab">
        <h3 class="cs-rc cs-tab-title">Callbacks</h3>
        <p><span>On slider init:
              <i>This JS code will be executed right after slider will be loaded.</i>
          </span>
          <textarea name="onInit" class="cs-text" ></textarea>
        </p>
        <p><span>On transition start callback JS code:
              <i>This JS code will be executed in the beginning of transition.</i></span>
          <textarea name="onTransitionStart" class="cs-text" ></textarea>
        </p>
        <p><span>On transition end callback JS code:
              <i>This JS code will be executed right after transition.</i></span>
          <textarea name="onTransitionEnd" class="cs-text" ></textarea>
        </p>
      </div>
    </div>
    <div style="clear:both"></div>
    <input type="hidden" name="create-chopslider" value="Save Slider" />
    <p style="margin:15px 0 15px 200px"><a class="submit-form cs-button-primary cs-rc" >Save Slider</a> <a href="admin.php?page=chopslider" class="cs-button-secondary cs-rc">Cancel</a></p>
  </form>
</div>


<?php include('chopslider-templates.php') ?>
