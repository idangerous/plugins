<?php
/**
 * ------- mOover Widget ------- 
*/
class Moover extends WP_Widget {
	/** constructor */
	function Moover() {
		parent::WP_Widget( 
			false, 
			$name = 'mOover', 
			array('description' => "Add mOover as a widget." ) 
		);
	}
	/** @see WP_Widget::widget */
	function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title; 
		global $wpdb;
		$moover_result = $wpdb->get_row('SELECT * FROM ' . MOOVER_TABLE_NAME . ' WHERE moover_id =' . $instance['id']);
		$wpdb->flush();
		if ($moover_result) {
			//JS
			global $moover_IDs;
			array_push($moover_IDs, $instance['id']);
			
			//Chop Slider's HTML
			echo getMooverHTML($moover_result);
		}
		echo $after_widget;
	}
	
	/** @see WP_Widget::update */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['id'] = strip_tags($new_instance['id']);
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}

	/** @see WP_Widget::form */
	function form( $instance ) {
		if ( $instance ) {
			$id = esc_attr( $instance[ 'id' ] );
			$title = esc_attr( $instance[ 'title' ] );
		}
		else {
			$id = 0;
			$title = __( 'New title', 'text_domain' );
		}
		?>
        <p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>Select mOover: <br />
        <select name="<?php echo $this->get_field_name('id'); ?>">
        <?php
		global $wpdb;
		$moover_result = $wpdb->get_results('SELECT moover_id, title FROM ' . MOOVER_TABLE_NAME . ' ORDER BY moover_id DESC'); 
		foreach ($moover_result as $single_moover){
			if ( $single_moover -> moover_id == $id) $selected = 'selected = "selected"';
			else $selected = '';
		?>	
            <option <?php echo $selected ?> value="<?php echo $single_moover -> moover_id ?>"><?php echo $single_moover -> title ?></option>
        <?php } ?>
        </select>
		</p>
        
		<?php 
	}

}
// register Moover widget
add_action( 'widgets_init', create_function( '', 'return register_widget("Moover");' ) );
?>