<?php
header ("Content-Type:	application/javascript; charset=utf-8");

$absolute_path = __FILE__;
$path_to_file = explode( 'wp-content', $absolute_path );
$path_to_wp = $path_to_file[0];

// Access to WordPress
require_once( $path_to_wp . '/wp-load.php' );

$mvID = $_GET['id'];
global $wpdb;
$mv_result = $wpdb->get_row('SELECT * FROM ' . MOOVER_TABLE_NAME . ' WHERE moover_id =' . $mvID); 
$wpdb->flush();
$moover = unserialize ($mv_result -> options);
?>
(function($){
	$(document).ready(function(){
    	var mv = $('.moover_<?php echo $mvID?>');
        var mooverIsVisible = $('.moover_<?php echo $mvID?>:visible').length>0;
        var mooverContent = mv.html();
        var mooverOptions = {
        	disableCSS3 : <?php echo $moover['disableCSS3'] ?>,
            manualMode : <?php if ( $moover['manualMode']==='true' ) echo "true"; else echo "false";?>,
            <?php 
			if ( $moover['navigation']==='true' ) echo "navigation : '.moover_$mvID .moover-pagination_$mvID',
			"  ;
			if ( $moover['navigationActive']==='true' ) echo "navigationActive : true,
			"; 
			if ( !empty($moover['playButton']) ) echo "playButton : '".$moover['playButton']."',
			"; 
			if ( !empty($moover['stopButton']) ) echo "stopButton : '".$moover['stopButton']."',
			";
			if ( !empty($moover['nextButton']) ) echo "nextButton : '".$moover['nextButton']."',
			";
			if ( !empty($moover['prevButton']) ) echo "prevButton : '".$moover['prevButton']."',"; ?>
			moveTime : <?php echo $moover['moveTime'] ?>,
            slideTime : <?php echo $moover['slideTime'] ?>,
            moveWidth : <?php echo $moover['moveWidth'] ?>,
            preloader : <?php echo $moover['preloader'] ?>,
            moveImage : <?php echo $moover['moveImage'] ?>,
            scaleImage : <?php echo $moover['scaleImage'] ?>,
            moveOutImage : true,
            waitForImage : true,
            stopOnLast : <?php echo ( $moover['stopOnLast']==='true' ? 'true' : 'false') ?>,
            reloadOnTabSwitch : <?php echo ( $moover['reloadOnTabSwitch']==='true' ? 'true' : 'false') ?>,
            effects : {
            <?php 
            $i=0;
            foreach ($moover['slides'] as $slide) { 
                $i++;
            ?>
            '<?php echo $i?>' : <?php echo $slide['js']?><?php if ($i<count($moover['slides'])) echo','; echo "\n" ?>
            <?php } ?>
			}<?php 
			if (!empty($moover['onStart'])) { echo ",
			onStart : function(){ $moover[onStart] }";
			}
			?><?php 
			if (!empty($moover['onSlideSwitch'])) { echo ",
			onSlideSwitch : function(){ $moover[onSlideSwitch] }";
			}
			?><?php 
			if (!empty($moover['onSlideSwitchEnd'])) { echo ",
			onSlideSwitchEnd : function(){ $moover[onSlideSwitchEnd] }";
			}
			?>
        }
		window.moover_<?php echo $mvID?> = mv.moover(mooverOptions);
        if ('onorientationchange' in window) {
        	window.onorientationchange = function(){ fixMooverResize() };
        }
        else {
        	$(window).resize(function(){ fixMooverResize() });
        }
        function fixMooverResize() {
        	var isVisible = $('.moover_<?php echo $mvID?>:visible').length>0;
            if (isVisible && !mooverIsVisible) {
                var newMV = mv.clone().insertAfter(mv).html(mooverContent);
                mv.remove();
                mv = $('.moover_<?php echo $mvID?>');
                window.moover_<?php echo $mvID?> = newMV.moover(mooverOptions);
            }
            mooverIsVisible = isVisible;
        }
        
        <?php if ( $moover['playPause']==='true' ) {?>
        mv.find('.moover-playpause').live('click', function(){
            if ($(this).hasClass('moover-pause')) {
                $('.moover_<?php echo $mvID?>').data('api').stop();
                $(this).removeClass('moover-pause').addClass('moover-play');
            }
            else {
                $('.moover_<?php echo $mvID?>').data('api').play();
                $(this).removeClass('moover-play').addClass('moover-pause');
            }
        });
        <?php } ?>
	})
})(jQuery);
