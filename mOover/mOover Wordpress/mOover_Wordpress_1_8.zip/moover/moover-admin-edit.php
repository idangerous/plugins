<?php
global $wpdb;
$mv_result = $wpdb->get_row('SELECT * FROM ' . MOOVER_TABLE_NAME . ' WHERE moover_id =' . $_GET['id']); 
$wpdb->flush();
$moover = unserialize ($mv_result -> options);

function isChecked($val1, $val2) {
	if ( $val1 == $val2 )
		echo 'checked="checked"';	
};
function isSelected($val1, $val2) {
	if ( $val1 == $val2 )
		echo 'selected="selected"';	
};
?>

<div class="wrap moover-form">
<div class="metabox-holder">
<h2>Edit mOover &quot;<?php echo $moover['title'] ?>&quot;</h2>
<form method="post" action="admin.php?page=moover" id="moover-addnew-form">
  <input type="hidden" name="moover_id" value="<?php echo $_GET['id'] ?>" />
  <input type="hidden" name="moover-new-version" value="<?php  echo ( $mv_result -> version + 1 ) ?>" />
  <div class="postbox">
    <h3 class="hndle"><span>Title</span></h3>
    <div class="inside">
      <table class="form-table">
        <tbody>
          <tr>
            <th scope="row"><label for="moover-title">Title <span class="description">(required) :</span></label></th>
            <td><input type="text" name="moover-title" id="moover-title" aria-required="true" value="<?php echo $moover['title'] ?>" style="width:300px" /></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="postbox">
    <h3 class="hndle"><span>Dimension</span></h3>
    <div class="inside">
      <table class="form-table">
        <tbody>
          <tr class="form-field">
            <th scope="row"><label>Dimension <span class="description">(required) :</span><br />
                <span class="cs-tip">If you want to make slider responsive, set width field in percents, e.g. <strong>100%</strong></span></label>
            <td><input type="text" name="moover-width" id="moover-d-width" aria-required="true" value="<?php echo $moover['width'] ?>" style="width:50px" />
              x
              <input type="text" name="moover-height" id="moover-d-height" aria-required="true" value="<?php echo $moover['height'] ?>" style="width:50px" />
              in px</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <h3 class="chop-slider-form-title">Slides</h3>
  <p style="margin-left:10px;">Use Drag &amp; Drop for re-ordering.</p>
  <ul id="moover-sortable" class="moover-slides">
    <?php   
	    foreach ($moover['slides'] as $slide) {
	    ?>
    <li>
      <div class="manage-controls">
          <div class="manage-edit" title="Edit Slide"></div>
          <div class="manage-copy" title="Copy Slide"></div>
          <div class="manage-html" title="Edit HTML"></div>
          <div class="manage-remove" title="Remove Slide"></div>
      </div>
      <div class="moover-slide-settings">
        <div class="moover-html"> <?php echo $slide['html'] ?> </div>
        <textarea name="moover-html[]"><?php echo $slide['html'] ?></textarea>
        <div class="moover-js"><?php echo $slide['js'] ?></div>
        <textarea name="moover-js[]"><?php echo $slide['js'] ?></textarea>
      </div>
    </li>
    <?php
		}
		?>
    <li class="ui-state-default sort-disabled manage-add">+</li>
  </ul>
  <script type="text/javascript">
  	(function($){
		$(function(){
			$('.moover-slides > li:not(.manage-add)').each(function(){
				var bg = $(this).find('.moover-html .moover-slide > img').attr('src');
				if (bg) $(this).css({backgroundImage:'url('+bg+')'});
			})	
		})
	})(jQuery);
  </script>
  <div class="mv-edit-html">
      <h3>Edit HTML of the slide:</h3>
      <textarea class="mv-slide-html"></textarea>
      <p><a class="button-primary" href="#">Save</a> <a class="button-secondary" href="#">Cancel</a> </p>
  </div>
  <div style="clear:both"></div>
  <div class="postbox">
    <h3 class="hndle"><span>Settings</span></h3>
    <div class="inside">
      <table class="form-table">
        <tbody>
          <tr>
            <th scope="row"><label>Move Background Image :<br />
                <span class="cs-tip">If 'move', than background image will be moving during the selected text effect</span></label></th>
            <td><select id="moveImage" name="moveImage">
                <option value="false" <?php isSelected($moover['moveImage'],'false') ?>>Do not move</option>
                <option value="true" <?php isSelected($moover['moveImage'],'true') ?>>Move</option>
              </select></td>
          </tr>
          <tr>
            <th scope="row"><label>Move Time :<br />
                <span class="cs-tip">Duration of background image movement. This value is also used by "Slide" text effect</span></label></th>
            <td><input type="text" name="moveTime" id="moveTime" value="<?php echo $moover['moveTime'] ?>" />
              ms</td>
          </tr>
          <tr>
            <th scope="row"><label>Move Width :<br />
                <span class="cs-tip">Background image will be moved during the text effect on this value/2. This value is also used by "Slide" text effect</span></label></th>
            <td><input type="text" name="moveWidth" id="moveWidth" value="<?php echo $moover['moveWidth'] ?>" />
              px</td>
          </tr>
          <tr>
            <th scope="row"><label>Slide In/Out Time :<br />
                <span class="cs-tip">Duration of slide-in/out animation between slides</span></label></th>
            <td><input id="slideTime" type="text" name="slideTime" value="<?php echo $moover['slideTime'] ?>" />
              ms</td>
          </tr>
          <tr>
            <th scope="row"><label>Scale Background Image :<br />
                <span class="cs-tip">Scale multiplier for the background image. It will be scaled to selected value during the text effect</span></label></th>
            <td><select id="scaleImage" name="scaleImage">
                <option value="false" <?php isSelected($moover['scaleImage'],'false') ?>>Do not scale</option>
                <option value="0.5" <?php isSelected($moover['scaleImage'],'0.5') ?>>0.5</option>
                <option value="0.6" <?php isSelected($moover['scaleImage'],'0.6') ?>>0.6</option>
                <option value="0.7" <?php isSelected($moover['scaleImage'],'0.7') ?>>0.7</option>
                <option value="0.8" <?php isSelected($moover['scaleImage'],'0.8') ?>>0.8</option>
                <option value="0.9" <?php isSelected($moover['scaleImage'],'0.9') ?>>0.9</option>
                <option value="1.1" <?php isSelected($moover['scaleImage'],'1.1') ?>>1.1</option>
                <option value="1.2" <?php isSelected($moover['scaleImage'],'1.2') ?>>1.2</option>
                <option value="1.3" <?php isSelected($moover['scaleImage'],'1.3') ?>>1.3</option>
                <option value="1.4" <?php isSelected($moover['scaleImage'],'1.4') ?>>1.4</option>
                <option value="1.5" <?php isSelected($moover['scaleImage'],'1.5') ?>>1.5</option>
              </select></td>
          </tr>
          <tr>
            <th scope="row"><label>Images Preloader :<br />
                <span class="cs-tip">If "Enabled", then slideshow will start only after all images will be loaded. Loading process will be indicated with preloader image</span></label></th>
            <td><select name="preloader">
                <option value="true"  <?php isSelected($moover['preloader'],'true') ?>>Enabled</option>
                <option value="false" <?php isSelected($moover['preloader'],'false') ?>>Disabled</option>
              </select></td>
          </tr>
          <tr>
              <th scope="row"><label>Stop On Last Slide:</label>
                <br />
                <span class="cs-tip">Set to "Stop" and mOover will stop its animation on last slide.</span> </th>
              <td><select id="stopOnLast" name="stopOnLast"><option <?php isSelected($moover['stopOnLast'],'false') ?> value="false">Do not stop</option><option <?php isSelected($moover['stopOnLast'],'true') ?> value="true">Stop</option></select></td>
            </tr>
            <tr>
              <th scope="row"><label>Autoplay:</label>
                </th>
              <td><select id="autoplay" name="manualMode"><option <?php isSelected($moover['manualMode'],'false') ?> value="false">Enabled</option><option value="true" <?php isSelected($moover['manualMode'],'true') ?>>Disabled</option></select></td>
            </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="postbox">
    <h3 class="hndle"><span>Pagination / Custom Controllers &nbsp;&nbsp;&nbsp; <a class="moover-expand-tg" href="#">Open</a></span></h3>
    <div class="inside">
      <div class="moover-tg-content">
        <table class="form-table">
          <tbody>
            <tr>
              <th scope="row"><label>Pagination :</label></th>
              <td><select name="navigation">
                  <option value="false"  <?php isSelected($moover['navigation'],'false') ?>>Disabled</option>
                  <option value="true" <?php isSelected($moover['navigation'],'true') ?>>Enabled</option>
                </select></td>
            </tr>
            <tr>
              <th scope="row"><label>Active Pagination :</label>
                <br />
                <span class="cs-tip">Set to "Enabled" if you want to make pagination buttons 'clickable'. In this case clicking on some pagination button will cause transition to appropriate slide</span></th>
              <td><select name="navigationActive">
                  <option value="false"  <?php isSelected($moover['navigationActive'],'false') ?>>Disabled</option>
                  <option value="true" <?php isSelected($moover['navigationActive'],'true') ?>>Enabled</option>
                </select></td>
            </tr>
            <tr>
            <th scope="row"><label>Play/Pause Button :</label>
              <br />
              <span class="cs-tip">Set to "Enabled" if you want to show default Play/Pause Button</span></th>
            <td><select name="playPause">
                <option value="false" <?php isSelected($moover['playPause'],'false') ?>>Disabled</option>
                <option value="true" <?php isSelected($moover['playPause'],'true') ?>>Enabled</option>
              </select></td>
          </tr>
            <tr>
              <th scope="row"><label>Custom "Stop" button :</label>
                <br />
                <span class="cs-tip">CSS selector of the element which will stop mOover.<br />
                For example: <strong>a.stop-moover</strong></span> </th>
              <td><input type="text" name="stopButton" value="<?php echo $moover['stopButton'] ?>" style="width:300px"></td>
            </tr>
            <tr>
              <th scope="row"><label>Custom "Play" button :</label>
                <br />
                <span class="cs-tip">CSS selector of the element which will launch mOover if it was stopped.<br />
                For example: <strong>a.play-moover</strong></span> </th>
              <td><input type="text" name="playButton" value="<?php echo $moover['playButton'] ?>" style="width:300px"></td>
            </tr>
            <tr>
              <th scope="row"><label>Custom "Next" button :</label>
                <br />
                <span class="cs-tip">CSS selector of the element which will cause transition to the next slide.<br />
                For example: <strong>a.next-slide</strong></span> </th>
              <td><input type="text" name="nextButton" value="<?php echo $moover['nextButton'] ?>" style="width:300px"></td>
            </tr>
            <tr>
              <th scope="row"><label>Custom "Previous" button :</label>
                <br />
                <span class="cs-tip">CSS selector of the element which will cause transition to the previous slide..<br />
                For example: <strong>a.prev-slide</strong></span> </th>
              <td><input type="text" name="prevButton" value="<?php echo $moover['prevButton'] ?>" style="width:300px"></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="postbox">
    <h3 class="hndle"><span>Additional Parameters (Fro Pro Users Only) &nbsp;&nbsp;&nbsp; <a class="moover-expand-tg" href="#">Open</a></span></h3>
    <div class="inside">
      <div class="moover-tg-content">
        <table class="form-table">
          <tbody>
            <tr>
              <th scope="row"><label>CSS3 Effects:</label>
                <br />
                <span class="cs-tip">By default mOover uses CSS3 transforms where possible (where possible). You can set to 'Disabled' to disable CSS3 transforms</span> </th>
              <td><select id="disableCSS3" name="disableCSS3">
                  <option  <?php isSelected($moover['disableCSS3'],'false') ?> value="false">Enabled</option>
                  <option  <?php isSelected($moover['disableCSS3'],'true') ?> value="true">Disabled</option>
                </select></td>
            </tr>
            <tr>
              <th scope="row"><label>Inactive Tab Reload:</label>
                <br />
                <span class="cs-tip">Set to "Reload" and slider will be reload when your site will be opened from inactive tab.</span> </th>
              <td><select id="reloadOnTabSwitch" name="reloadOnTabSwitch"><option <?php isSelected($moover['reloadOnTabSwitch'],'false') ?> value="false">Do not reload</option><option <?php isSelected($moover['reloadOnTabSwitch'],'true') ?> value="true">Reload</option></select></td>
            </tr>
            
            
            <tr>
              <th scope="row"><label><strong>onStart</strong> Callback :</label>
                <br />
                <span class="cs-tip">JavaScript code that will be executed on mOover's initialization<br />
                <strong>For example : alert('Hello World')</strong></span> </th>
              <td><textarea  name="onStart"  style="width:300px" rows="3"><?php echo $moover['onStart'] ?></textarea></td>
            </tr>
            <tr>
              <th scope="row"><label><strong>onSlideSwitch</strong> Callback  :</label>
                <br />
                <span class="cs-tip">JavaScript code will be executed in the beginning of transition to next slide<br />
                <strong>For example : alert('Slide is changing')</strong></span> </th>
              <td><textarea name="onSlideSwitch" rows="3"  style="width:300px"><?php echo $moover['onSlideSwitch'] ?></textarea></td>
            </tr>
            <tr>
              <th scope="row"><label><strong>onSlideSwitchEnd</strong> Callback  :</label>
                <br />
                <span class="cs-tip">JavaScript code will be executed right after transition to next slide <br />
                <strong>For example : alert('Slide changed')</strong></span> </th>
              <td><textarea name="onSlideSwitchEnd" rows="3" style="width:300px"><?php echo $moover['onSlideSwitchEnd'] ?></textarea></td>
            </tr>
            
            
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <h2>Save mOover</h2>
  <input type="submit" value="Save mOover" class="button-primary" name="save-edited-moover">
  <a class="button-secondary" href="admin.php?page=moover">Cancel</a>
</form>

<!--New Slide Template-->
<ul class="moover-slide-template">
  <li class="ui-state-default">
    <div class="manage-controls">
      <div class="manage-edit" title="Edit Slide"></div>
      <div class="manage-copy" title="Copy Slide"></div>
      <div class="manage-html" title="Edit HTML"></div>
      <div class="manage-remove" title="Remove Slide"></div>
    </div>
    <div class="moover-slide-settings">
    <div class="moover-html">
      <div class="moover-slide moover-absolute">
        <div class="moover-text"></div>
      </div>
    </div>
    <textarea name="moover-html[]"><div class="moover-slide moover-absolute"><div class="moover-text"></div></div>
</textarea>
    <div class="moover-js">{effect:'slide', moveWidth:100, moveTime:3000, textLineDelay:0, crossSideLines:true, lineFrom:'right', transformPreset:'none'}</div>
      <textarea name="moover-js[]">{'effect':'slide', moveWidth:100, moveTime:3000, textLineDelay:0, crossSideLines:true, lineFrom:'right', transformPreset:'none'}</textarea>
  </div>
  </li>
</ul>
</div>
</div>
<?php
include('moover-slide-editor.php');
?>
