<?php
/**
 * ------- Moover Short Code ------- 
**/
class Moover_Shortcode {
	static $add_script;
	function init() {
		add_shortcode('moover', array(__CLASS__, 'handle_moover_shortcode'));
	}	
	function handle_moover_shortcode($atts) {
		extract(shortcode_atts(array( "id" => '' ), $atts));
		global $wpdb;
		$moover_result = $wpdb->get_row('SELECT * FROM ' . MOOVER_TABLE_NAME . ' WHERE moover_id =' . $id);
		if (!$moover_result) return;
		
		//JS
		global $moover_IDs;
		array_push($moover_IDs, $id);
		
		//Return mOover's HTML
		return getMooverHTML($moover_result);
	}
}
Moover_Shortcode::init();
?>