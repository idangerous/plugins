<?php
/**
 * ------- mOover Custom Template Tag ------- 
*/

function moover($id) {
	global $wpdb;
	$moover_result = $wpdb->get_row('SELECT * FROM ' . MOOVER_TABLE_NAME . ' WHERE moover_id =' . $id);
	$wpdb->flush();
	
	if (!$moover_result) return;
		
	//JS
	global $moover_IDs;
	array_push($moover_IDs, $id);
	
	//Echo mOover's HTML
	echo getMooverHTML($moover_result);
	
}
?>