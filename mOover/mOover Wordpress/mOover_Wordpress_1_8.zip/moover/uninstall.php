<?php
/* We need to remove the mOover's table on uninstallation */
if(!defined ( 'WP_UNINSTALL_PLUGIN' ) ) exit();
$removeDB = get_option('moover-settings');
if ($removeDB['remove_db']==1) {
	global $wpdb;
	$mooverTableName = $wpdb->prefix . "id_moover";
	$sql = "DROP TABLE " . $mooverTableName;
	$wpdb->query($sql);
	delete_option('moover-settings');
}
?>